<?php /*
Classe pour utiliser la DLL LDAPC fournit par PSA
Nom : class_ldapc
D�velopp� le : 06/06/2006
part : E250306	- Yannick MONGE (Alti)


Le constructeur teste la connection � LDAP si il y a une erreur on affiche le message d'erreur
lookInLdapcIdentify <== verifie le login et mot de passe qu'on lui donne en param�tre.
lookInLdapcInfos <== recupere les infos d'un Code RPI (nom , prenom)
la structure des 2 fonctions precedentes a �t� conserv� afin de conserver un comptatibilit� avec l'anciene classe LDAP


*/
class Class_ldapc{

	var $sPropertiesFiles;
	
	//construteur de la classe class/ldap//pas de param�tre on va cherche le fichier lsi.ldap.properties � la racine du site
	function __construct($p_sPropertiesFiles="application/libraries/ldap.properties"){
		$this->sPropertiesFiles=$p_sPropertiesFiles;
		
		$Resultat=LDAPC_NEW($this->sPropertiesFiles);
		
		if ($Resultat!=1){
			print("<div align='center'>*****************************************************************************************************<bR>");
			print("<b>Erreur de la classe class_ldapc</b><bR>");
			print(getLdapErrorMsg()." -- <br>");
			print("*****************************************************************************************************</div>");		
		}
	//	LDAPC_END();
	}


	//fonction qui retourne tableau login = reponse(denied ou granted) et why retourne la raison du refus
	function lookInLdapcIdentify($p_sRPI,$p_sPwd){
		$ArrRetour="";
		 if(($p_sRPI=='') || ($p_sPwd=='')){ 
		 	$ArrRetour=array("login"=>"denied", "why"=>"Identifiant et mot de passe obligatoires.");
  		} else {
			//echo LDAPC_NEW("application/libraries/ldap.properties");
			
			$pUser  = findLdapUserByUid($p_sRPI);
			//print_r($p_sRPI);
			//print_r("LDAP");
			//echo $p_sRPI;
			//print_r($pUser);
			if (isObjectNotNull($pUser)) {
		 		if (authenticateLdapUser($pUser,$p_sPwd)){
					// Utilisateur authentifi�
					$ArrRetour=array("login"=>"granted", "why"=>"");
	 			} else {
					//utilisateur non authentifi�
					$ArrRetour=array("login"=>"denied", "why"=>"Mot de passe incorrect.");
				}
	 			// on libere toujours l�objet utilisateur si ce dernier n�est pas     null
 				freeLdapPtrUser($pUser);
			} else {
				$ArrRetour=array("login"=>"denied", "why"=>"Identifiant incorrect.");
			}
			LDAPC_END();
		}
		return $ArrRetour;
	}

	//fonction que retourne un tableau contenant les informations d'un utilisateur.
	function lookInLdapcInfos($p_sRPI){
		if ($p_sRPI!=""){
			LDAPC_NEW($this->sPropertiesFiles);
			$pUser  = findLdapUserByUid($p_sRPI);
			//$pUser  = findLdapUserByUid("P982621");
			
/* 
char *  getLdapUserUid (LDAPUser *pUser) 
  R�cup�re l'attribut UID d'un utilisateur. 
 
char *  getLdapUserAgape (LDAPUser *pUser) 
  R�cup�re le code AGAPE (ou RH) d'un utilisateur. 

char *  getLdapUserCn (LDAPUser *pUser) 
  R�cup�re l'attribut cn d'un utilisateur. 
 
char *  getLdapUserMainMail (LDAPUser *pUser) 
  R�cup�re l'attribut mail d'un utilisateur. 
 
char *  getLdapUserFirstName (LDAPUser *pUser) 
  Retourne le Pr�nom d'un utilisateur. 
 
char *  getLdapUserDirection (LDAPUser *pUser) 
  Retourne la direction d'un utilisateur. 
 
char *  getLdapUserLastName (LDAPUser *pUser) 
  Retourne le nom d'un utilisateur.
 
char *  getLdapUserCodeUo (LDAPUser *pUser) 
  Retourne le code UO du rattachement hi�rarchique. 
			*/
			if (isObjectNotNull($pUser)==1) {
				$ArrRetour=array("login"=>"", 
					"why"=>"",
					"user"=>array("id"=>getLdapUserUid($pUser), 
							"UserAgape"=>getLdapUserAgape ($pUser),
							"name"=>getLdapUserLastName($pUser), 
							"firstname"=>getLdapUserFirstName($pUser),
							"mail"=>getLdapUserMainMail ($pUser),
							"workPlace"=>getLdapUserWorkPlaceLabel($pUser),
							"tel"=>getLdapUserTelInt1($pUser),
							"direction"=>getLdapUserDirection($pUser),
							"fournisseur"=>getLdapUserExtCompany($pUser),
							"CA"=>getLdapUserBudgetCenter($pUser),
							"hierar"=>getLdapUserCodeUo($pUser))
					);
				freeLdapPtrUser($pUser);					
			} else{
				$ArrRetour=array("login"=>"", "why"=>"","user"=>array($p_sRPI, "", ""));
			}
			LDAPC_END();	
		} else {
			$ArrRetour=array("login"=>"", "why"=>"","user"=>array("", "", ""));
		}
		return $ArrRetour;
	}
	
	public function test_lookInLdapcInfos($p_sRPI){
		
		if ($p_sRPI!=""){
			LDAPC_NEW($this->sPropertiesFiles);
			$pUser  = findLdapUserByUid($p_sRPI);
			//$pUser  = findLdapUserByUid("P982621");
			
			/*
			 char *  getLdapUserUid (LDAPUser *pUser)
			 R�cup�re l'attribut UID d'un utilisateur.
			 
			 char *  getLdapUserAgape (LDAPUser *pUser)
			 R�cup�re le code AGAPE (ou RH) d'un utilisateur.
			 
			 char *  getLdapUserCn (LDAPUser *pUser)
			 R�cup�re l'attribut cn d'un utilisateur.
			 
			 char *  getLdapUserMainMail (LDAPUser *pUser)
			 R�cup�re l'attribut mail d'un utilisateur.
			 
			 char *  getLdapUserFirstName (LDAPUser *pUser)
			 Retourne le Pr�nom d'un utilisateur.
			 
			 char *  getLdapUserDirection (LDAPUser *pUser)
			 Retourne la direction d'un utilisateur.
			 
			 char *  getLdapUserLastName (LDAPUser *pUser)
			 Retourne le nom d'un utilisateur.
			 
			 char *  getLdapUserCodeUo (LDAPUser *pUser)
			 Retourne le code UO du rattachement hi�rarchique.
			 */
			error_reporting(0);
			
			$pUser1 = $pUser;
			$user_array = array();
			//$string = getLdapUserUid($p_sRPI);
			if (isObjectNotNull($pUser1)==1) {
				$string = getLdapUserUid($pUser1);
			}
			$user_array['UID'] = ($string)?$string:"NULL";;
			//printf("\t => UID       :%s\n", ($string)?$string:"NULL");
			$string= getLdapUserEmployeeType($pUser1);
			
			//printf("\t => Emp type :%s\n", ($string)?$string:"NULL");
			$user_array['emp_type'] = ($string)?$string:"NULL";;
			$string= getLdapUserEmployeeSubType($pUser1);
			$user_array['emp_subtype'] = ($string)?$string:"";;
			$roleDns = getLdapUserRolesName($pUser1);
			if ($roleDns != 0)
			{
				$i = 0;
				$role = getListCharElement($roleDns,$i);
				while ($role != 0)
				{
					//printf("=> ROLE : $role\n");
					$i++;
					$role = getListCharElement($roleDns,$i);
				}
			}
			//printf("\t => Roles :%s\n", ($string)?$string:"NULL");
			$user_array['role'] = ($string)?$string:"NULL";;
			$string = getLdapUserFirstName($pUser1);
			//printf("\t => FirstName :%s\n", ($string)?$string:"NULL");
			$user_array['firstname'] = ($string)?$string:"NULL";;
			
			$string = getLdapUserTelExt1($pUser1);
			//printf("\t => Telephone :%s\n", ($string)?$string:"NULL");
			$user_array['telephone'] = ($string)?$string:"NULL";;
			
			$string = getLdapUserFirstName2($pUser1);
			//printf("\t => FirstName2 :%s\n", ($string)?$string:"NULL");
			
			$string = getLdapUserLastName($pUser1);
			//printf("\t => LastName  :%s\n", ($string)?$string:"NULL");
			$user_array['last_name'] = ($string)?$string:"NULL";;
			
			$string = getLdapUserLastName1($pUser1);
			//printf("\t => sn        :%s\n", ($string)?$string:"NULL");
			
			
			$string = getLdapUserLastName2($pUser1);
			//printf("\t => Surname2  :%s\n", ($string)?$string:"NULL");
			
			$string = getLdapUserPays($pUser1);
			$user_array['pays'] = ($string)?$string:"NULL";;
			
			$string = getLdapUserLocale($pUser1);
			//printf("\t => Locale    :%s\n", ($string)?$string:"NULL");
			$user_array['locale'] = ($string)?$string:"NULL";;
			
			$string = getLdapUserMail($pUser1);
			$user_array['mail'] = ($string)?$string:"NULL";;
			//printf("\t => Email     :%s\n", ($string)?$string:"NULL");
			
			$string = getLdapUserDirection($pUser1);
			//printf("\t => Direction :%s\n", ($string)?$string:"NULL");
			$user_array['direction'] = ($string)?$string:"NULL";;
			
			$string = getLdapUserAgape($pUser1);
			//printf("\t => Agape     :%s\n", ($string)?$string:"NULL");
			
			$string = getLdapUserPays($pUser1);
			//printf("\t => Pays      :%s\n", ($string)?$string:"NULL");
			
			$string = getLdapUserMarque($pUser1);
			//printf("\t => Marque    :%s\n", ($string)?$string:"NULL");
			
			$string = getLdapUserTelExt1($pUser1);
			//printf("\t => Tel ext1  :%s\n", ($string)?$string:"NULL");
			$user_array['tel_ext_1'] = ($string)?$string:"NULL";;
			
		
			
			
			
			$string = getLdapUserWorkPlace($pUser1);
			//printf("\t => Workplace Code     :%s\n", ($string)?$string:"NULL");
			$user_array['codelw'] = ($string)?$string:"NULL";;
			$authent = hasLdapUserSupplier($pUser1);
			$user_array['is_supplier'] = '0';
			if ($authent)
			{
				//printf("\t => Supplier   : YES\n");
				$user_array['is_supplier'] = '1';
				//printf("\t => Passport BN:%s\n",getLdapPassportBusinessName(getLdapUserPassport($pUser1)));
			}
			else{
				//printf("\t => Supplier   : NO\n");
			}
				
						/*$string = getLdapUserUnixId($pUser1);
						printf("\t => Unix ID     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserUnixUid($pUser1);
						printf("\t => Unix UID     :%s\n", ($string)?$string:"NULL");
						
						$string = getLdapUserPersonalTitle($pUser1);
						printf("\t => Personal Title     :%s\n", ($string)?$string:"NULL");
						
						
						$tabStr = getLdapUserFonctions($pUser1);
						$i = 0;
						if (isObjectNotNull($tabStr))
						{
							while ($string = getListCharElement($tabStr,$i))
							{
								printf("\t => Fonction       :%s\n", $string);
								$i++;
							}
						}
						
						
						$tabStr = getLdapUserCodeUoFct($pUser1);
						$i = 0;
						if (isObjectNotNull($tabStr))
						{
							while ($string = getListCharElement($tabStr,$i))
							{
								printf("\t => Uofct       :%s\n", $string);
								$i++;
							}
						}
						$string = getLdapUserCodeUo($pUser1);
						printf("\t => CodeUo     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserSecretary($pUser1);
						printf("\t => Secraitaire     :%s\n", ($string)?$string:"NULL");
						
						
						
// 						$pSiteGeo = getLdapUserPrimarySiteGeo($pUser1);
// 						printSiteGeo($pSiteGeo);
// 						freeLdapPtrSiteGeo($pSiteGeo);
// 						$pSiteGeo = getLdapUserSecondarySiteGeo($pUser1);
// 						printSiteGeo($pSiteGeo);
// 						freeLdapPtrSiteGeo($pSiteGeo);
						
						
						$string = getLdapUserContractType($pUser1);
						printf("\t => ContractType     :%s\n", ($string)?$string:"NULL");*/
						
						$string = getLdapUserAdminSiteCode($pUser1);
						//printf("\t => AdminSiteCode     :%s\n", ($string)?$string:"NULL");
						$user_array['admin_sitecode'] = ($string)?$string:"NULL";
						$string = getLdapUserIntCompany($pUser1);
						$user_array['idjvcompany'] = ($string)?$string:"NULL";
						
						$string = getLdapUserIdResp($pUser1);
						$user_array['manageruid'] = ($string)?$string:"NULL";
						//print_R($user_array);
						return $user_array;
					/*	$i=0;
						$i = isLdapUserResponsibleOfUo($pUser1);
						printf("\t => UoResp ?     :%d\n", $i);
						
						
						
						$string = getLdapUserBudgetCenter($pUser1);
						printf("\t => getLdapUserBudgetCenter     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserIntCompany($pUser1);
						printf("\t => getLdapUserIntCompany     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserExtCompany($pUser1);
						printf("\t => getLdapUserExtCompany     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserIdResp($pUser1);
						printf("\t => getLdapUserIdResp     :%s\n", ($string)?$string:"NULL");
						
						$string = getLdapUserBuilding($pUser1);
						printf("\t => getLdapUserBuilding     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserBuilding2($pUser1);
						printf("\t => getLdapUserBuilding2     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserFloor($pUser1);
						printf("\t => getLdapUserFloor     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserFloor2($pUser1);
						printf("\t => getLdapUserFloor2     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserLanding($pUser1);
						printf("\t => getLdapUserLanding     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserLanding2($pUser1);
						printf("\t => getLdapUserLanding2     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserRoomNum($pUser1);
						printf("\t => getLdapUserRoomNum     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserRoomNum2($pUser1);
						printf("\t => getLdapUserRoomNum2     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserMailBox($pUser1);
						printf("\t => getLdapUserMailBox     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserMailBox2($pUser1);
						printf("\t => getLdapUserMailBox2     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserSiteTechCode($pUser1);
						printf("\t => getLdapUserSiteTechCode     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserSiteTechLabel($pUser1);
						printf("\t => getLdapUserSiteTechLabel     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserValidity($pUser1);
						printf("\t => getLdapUserValidity     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserComments($pUser1);
						printf("\t => getLdapUserComments     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserLocalPrinter($pUser1);
						printf("\t => getLdapUserLocalPrinter     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserSysPrinter($pUser1);
						printf("\t => getLdapUserSysPrinter     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserCasier($pUser1);
						printf("\t => getLdapUserCasier     :%s\n", ($string)?$string:"NULL");
						
						
						$string = getLdapUserSiteGeoCode($pUser1);
						printf("\t => getLdapUserSiteGeoCode     :%s\n", ($string)?$string:"NULL");
						$string = getLdapUserSiteGeoCode2($pUser1);
						printf("\t => getLdapUserSiteGeoCode2     :%s\n", ($string)?$string:"NULL");
						
						
						
						$dealersList	= getLdapUserDealnetworks($pUser1);
						
						if (isObjectNotNull($dealersList))
						{
							$i=0;
							$pDealer = getListDealNetworkElement($dealersList,$i);
							while (  isObjectNotNull($pDealer)  )
							{
								printf("DealActivity :%s\n",getLdapDealNetworkActivity($pDealer));
								printf("DealCode :%s\n",getLdapDealNetworkCode($pDealer));
								printf("DealType :%s\n",getLdapDealNetworkType($pDealer));
								printf("DealDate :%s\n",getLdapDealNetworkDate($pDealer));
								$i++;
								$pDealer = getListDealNetworkElement($dealersList,$i);
							}
							//freeLdapPtrListDealNetwork($dealersList);
						}
						
						if (isObjectNotNull($pUser)==1) {
							$ArrRetour=array("login"=>"",
									"why"=>"",
									"user"=>array("id"=>getLdapUserUid($pUser),
											"UserAgape"=>getLdapUserAgape ($pUser),
											"name"=>getLdapUserLastName($pUser),
											"firstname"=>getLdapUserFirstName($pUser),
											"mail"=>getLdapUserMainMail ($pUser),
											"workPlace"=>getLdapUserWorkPlaceLabel($pUser),
											"tel"=>getLdapUserTelInt1($pUser),
											"direction"=>getLdapUserDirection($pUser),
											"fournisseur"=>getLdapUserExtCompany($pUser),
											"CA"=>getLdapUserBudgetCenter($pUser),
											"hierar"=>getLdapUserCodeUo($pUser),)
							);
							freeLdapPtrUser($pUser);
						} else{
							$ArrRetour=array("login"=>"", "why"=>"","user"=>array($p_sRPI, "", ""));
						}
						*/
						LDAPC_END();
		} else {
			//$ArrRetour=array("login"=>"", "why"=>"","user"=>array("", "", ""));
		}
		//return $ArrRetour;
		
	}
	
	//fonction que retourne un tableau contenant les informations d'un utilisateur.
	function lookInLdapcEmail($p_sRPI){
		if ($p_sRPI!=""){
			LDAPC_NEW($this->sPropertiesFiles);
			$pUser  = findLdapUserByUid($p_sRPI);
			//$pUser  = findLdapUserByUid("P982621");
			if (isObjectNotNull($pUser)==1) {
				$email = getLdapUserMainMail ($pUser);
				freeLdapPtrUser($pUser);					
			} else{
				$email = "";
			}
			LDAPC_END();	
		} else {
			$email = "";
		}
		return $email;
	}
	
	function lookChiefEntity($p_sRPI){
		LDAPC_NEW($this->sPropertiesFiles);
			$pUser  = findLdapUserByUid($p_sRPI);
			if (isObjectNotNull($pUser)==1) {
				$entite = getLdapEntityOwner(findLdapEntityByUoCode(getLdapUserCodeUo($pUser)));
				$tabEntite=array();
				$tabEntite = explode(',',$entite);
				$responsable = substr($tabEntite[0],3);
				
				freeLdapPtrUser($pUser);					
			} 
			else{
				$responsable='';
			}
			LDAPC_END();	
			return $responsable;
	}
	
	function printUserOwnedEntities($uid)
	{
		//echo $uid;exit;
		//$pUser	= findLdapUserByUid($uid);
		$pUser = $uid;
		//echo $pUser;exit;
		
		if (isObjectNotNull($pUser))
		{
			PrintUser($pUser);
			echo("<H2>Liste des Entit�s adminisr�s hi�rarchiquement par $uid : </H2><BR>");
			
			
			$pSearchCriteria = initLdapSearchCriteria();
			
			$resCode = addLdapSearchCriteria($pSearchCriteria,SEARCH_CRITERIA_ORGUNIT_OWNER,getLdapUserDn($pUser),SEARCH_TYPE_EQUAL);
			$resCode &= addLdapSearchCriteria($pSearchCriteria,SEARCH_CRITERIA_VALIDITY,"ORGA_NP_NM",SEARCH_TYPE_EQUAL);
			$resCode &= addLdapSearchCriteria($pSearchCriteria,SEARCH_CRITERIA_VALIDITY,"ORGA",SEARCH_TYPE_EQUAL);
			
			if ($resCode)
			{
				
				$listEntities = findLdapEntitiesBySearchCriteria($pSearchCriteria);
				freeLdapSearchCriteria($pSearchCriteria);
			}
			else
			{
				$err = getLdapErrorMsg();
			}
			$i = 0;
			
			
			if (isObjectNotNull($listEntities))
			{
				
				$entity = getListEntitiesElement($listEntities,$i);
				while (isObjectNotNull($entity))
				{
					printEntity($entity);
					
					$i++;
					$entity = getListEntitiesElement($listEntities,$i);
				}
				freeLdapPtrListEntity($listEntities);
			}
			else
			{
				echo("<H2>Aucune</H2>");
			}
			
			freeLdapPtrUser($pUser);
		}
	}
	
	public function test_new_lookInLdapcInfos($p_sRPI){
		
		if ($p_sRPI!=""){
			LDAPC_NEW($this->sPropertiesFiles);
			$pUser  = findLdapUserByUid($p_sRPI);
			//$pUser  = findLdapUserByUid("P982621");
			
			/*
			 char *  getLdapUserUid (LDAPUser *pUser)
			 R�cup�re l'attribut UID d'un utilisateur.
			 
			 char *  getLdapUserAgape (LDAPUser *pUser)
			 R�cup�re le code AGAPE (ou RH) d'un utilisateur.
			 
			 char *  getLdapUserCn (LDAPUser *pUser)
			 R�cup�re l'attribut cn d'un utilisateur.
			 
			 char *  getLdapUserMainMail (LDAPUser *pUser)
			 R�cup�re l'attribut mail d'un utilisateur.
			 
			 char *  getLdapUserFirstName (LDAPUser *pUser)
			 Retourne le Pr�nom d'un utilisateur.
			 
			 char *  getLdapUserDirection (LDAPUser *pUser)
			 Retourne la direction d'un utilisateur.
			 
			 char *  getLdapUserLastName (LDAPUser *pUser)
			 Retourne le nom d'un utilisateur.
			 
			 char *  getLdapUserCodeUo (LDAPUser *pUser)
			 Retourne le code UO du rattachement hi�rarchique.
			 */
			error_reporting(0);
			
			$pUser1 = $pUser;
			$user_array = array();
			//$string = getLdapUserUid($p_sRPI);
			if (isObjectNotNull($pUser1)==1) {
				$string = getLdapUserUid($pUser1);
			}
			$user_array['UID'] = ($string)?$string:"NULL";;
			//printf("\t => UID       :%s\n", ($string)?$string:"NULL");
			$string= getLdapUserEmployeeType($pUser1);
			
			//printf("\t => Emp type :%s\n", ($string)?$string:"NULL");
			$user_array['emp_type'] = ($string)?$string:"NULL";;
			$string= getLdapUserEmployeeSubType($pUser1);
			$user_array['emp_subtype'] = ($string)?$string:"";;
			$roleDns = getLdapUserRolesName($pUser1);
			if ($roleDns != 0)
			{
				$i = 0;
				$role = getListCharElement($roleDns,$i);
				while ($role != 0)
				{
					//printf("=> ROLE : $role\n");
					$i++;
					$role = getListCharElement($roleDns,$i);
				}
			}
			//printf("\t => Roles :%s\n", ($string)?$string:"NULL");
			$user_array['role'] = ($string)?$string:"NULL";;
			$string = getLdapUserFirstName($pUser1);
			//printf("\t => FirstName :%s\n", ($string)?$string:"NULL");
			$user_array['firstname'] = ($string)?$string:"NULL";;
			
			$string = getLdapUserTelExt1($pUser1);
			//printf("\t => Telephone :%s\n", ($string)?$string:"NULL");
			$user_array['telephone'] = ($string)?$string:"NULL";;
			
			$string = getLdapUserFirstName2($pUser1);
			//printf("\t => FirstName2 :%s\n", ($string)?$string:"NULL");
			
			$string = getLdapUserLastName($pUser1);
			//printf("\t => LastName  :%s\n", ($string)?$string:"NULL");
			$user_array['last_name'] = ($string)?$string:"NULL";;
			
			$string = getLdapUserLastName1($pUser1);
			//printf("\t => sn        :%s\n", ($string)?$string:"NULL");
			
			
			$string = getLdapUserLastName2($pUser1);
			//printf("\t => Surname2  :%s\n", ($string)?$string:"NULL");
			
			$string = getLdapUserLocale($pUser1);
			//printf("\t => Locale    :%s\n", ($string)?$string:"NULL");
			$user_array['locale'] = ($string)?$string:"NULL";;
			
			$string = getLdapUserMail($pUser1);
			$user_array['mail'] = ($string)?$string:"NULL";;
			//printf("\t => Email     :%s\n", ($string)?$string:"NULL");
			
			$string = getLdapUserDirection($pUser1);
			//printf("\t => Direction :%s\n", ($string)?$string:"NULL");
			$user_array['direction'] = ($string)?$string:"NULL";;
			
			$string = getLdapUserAgape($pUser1);
			printf("\t => Agape     :%s\n", ($string)?$string:"NULL");
			
			$string = getLdapUserPays($pUser1);
			printf("\t => Pays      :%s\n", ($string)?$string:"NULL");
			
			$string = getLdapUserMarque($pUser1);
			printf("\t => Marque    :%s\n", ($string)?$string:"NULL");
			
			$string = getLdapUserTelExt1($pUser1);
			printf("\t => Tel ext1  :%s\n", ($string)?$string:"NULL");
			$user_array['tel_ext_1'] = ($string)?$string:"NULL";;
			
			
			
			
			
			$string = getLdapUserWorkPlace($pUser1);
			printf("\t => Workplace Code     :%s\n", ($string)?$string:"NULL");
			$user_array['codelw'] = ($string)?$string:"NULL";;
			$authent = hasLdapUserSupplier($pUser1);
			$user_array['is_supplier'] = '0';
			if ($authent)
			{
				printf("\t => Supplier   : YES\n");
				$user_array['is_supplier'] = '1';
				printf("\t => Passport BN:%s\n",getLdapPassportBusinessName(getLdapUserPassport($pUser1)));
			}
			else{
				printf("\t => Supplier   : NO\n");
			}
			
			$string = getLdapUserUnixId($pUser1);
			 printf("\t => Unix ID     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserUnixUid($pUser1);
			 printf("\t => Unix UID     :%s\n", ($string)?$string:"NULL");
			 
			 $string = getLdapUserPersonalTitle($pUser1);
			 printf("\t => Personal Title     :%s\n", ($string)?$string:"NULL");
			 
			 
			 $tabStr = getLdapUserFonctions($pUser1);
			 $i = 0;
			 if (isObjectNotNull($tabStr))
			 {
			 while ($string = getListCharElement($tabStr,$i))
			 {
			 printf("\t => Fonction       :%s\n", $string);
			 $i++;
			 }
			 }
			 
			 
			 $tabStr = getLdapUserCodeUoFct($pUser1);
			 $i = 0;
			 if (isObjectNotNull($tabStr))
			 {
			 while ($string = getListCharElement($tabStr,$i))
			 {
			 printf("\t => Uofct       :%s\n", $string);
			 $i++;
			 }
			 }
			 $string = getLdapUserCodeUo($pUser1);
			 printf("\t => CodeUo     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserSecretary($pUser1);
			 printf("\t => Secraitaire     :%s\n", ($string)?$string:"NULL");
			 
			 
			 
  			$pSiteGeo = getLdapUserPrimarySiteGeo($pUser1);
  			printf($pSiteGeo);
 						freeLdapPtrSiteGeo($pSiteGeo);
 						$pSiteGeo = getLdapUserSecondarySiteGeo($pUser1);
 						printf($pSiteGeo);
 						freeLdapPtrSiteGeo($pSiteGeo);
			 
			 
			 $string = getLdapUserContractType($pUser1);
			 printf("\t => ContractType     :%s\n", ($string)?$string:"NULL");
			
			$string = getLdapUserAdminSiteCode($pUser1);
			//printf("\t => AdminSiteCode     :%s\n", ($string)?$string:"NULL");
			$user_array['admin_sitecode'] = ($string)?$string:"NULL";
			$string = getLdapUserIntCompany($pUser1);
			$user_array['idjvcompany'] = ($string)?$string:"NULL";
			//print_R($user_array);
			//return $user_array;
				$i=0;
			 $i = isLdapUserResponsibleOfUo($pUser1);
			 printf("\t => UoResp ?     :%d\n", $i);
			 
			 
			 
			 $string = getLdapUserBudgetCenter($pUser1);
			 printf("\t => getLdapUserBudgetCenter     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserIntCompany($pUser1);
			 printf("\t => getLdapUserIntCompany     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserExtCompany($pUser1);
			 printf("\t => getLdapUserExtCompany     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserIdResp($pUser1);
			 printf("\t => getLdapUserIdResp     :%s\n", ($string)?$string:"NULL");
			 
			 $string = getLdapUserBuilding($pUser1);
			 printf("\t => getLdapUserBuilding     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserBuilding2($pUser1);
			 printf("\t => getLdapUserBuilding2     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserFloor($pUser1);
			 printf("\t => getLdapUserFloor     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserFloor2($pUser1);
			 printf("\t => getLdapUserFloor2     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserLanding($pUser1);
			 printf("\t => getLdapUserLanding     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserLanding2($pUser1);
			 printf("\t => getLdapUserLanding2     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserRoomNum($pUser1);
			 printf("\t => getLdapUserRoomNum     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserRoomNum2($pUser1);
			 printf("\t => getLdapUserRoomNum2     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserMailBox($pUser1);
			 printf("\t => getLdapUserMailBox     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserMailBox2($pUser1);
			 printf("\t => getLdapUserMailBox2     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserSiteTechCode($pUser1);
			 printf("\t => getLdapUserSiteTechCode     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserSiteTechLabel($pUser1);
			 printf("\t => getLdapUserSiteTechLabel     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserValidity($pUser1);
			 printf("\t => getLdapUserValidity     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserComments($pUser1);
			 printf("\t => getLdapUserComments     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserLocalPrinter($pUser1);
			 printf("\t => getLdapUserLocalPrinter     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserSysPrinter($pUser1);
			 printf("\t => getLdapUserSysPrinter     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserCasier($pUser1);
			 printf("\t => getLdapUserCasier     :%s\n", ($string)?$string:"NULL");
			 
			 
			 $string = getLdapUserSiteGeoCode($pUser1);
			 printf("\t => getLdapUserSiteGeoCode     :%s\n", ($string)?$string:"NULL");
			 $string = getLdapUserSiteGeoCode2($pUser1);
			 printf("\t => getLdapUserSiteGeoCode2     :%s\n", ($string)?$string:"NULL");
			 
			 
			 
			 $dealersList	= getLdapUserDealnetworks($pUser1);
			 
			 if (isObjectNotNull($dealersList))
			 {
			 $i=0;
			 $pDealer = getListDealNetworkElement($dealersList,$i);
			 while (  isObjectNotNull($pDealer)  )
			 {
			 printf("DealActivity :%s\n",getLdapDealNetworkActivity($pDealer));
			 printf("DealCode :%s\n",getLdapDealNetworkCode($pDealer));
			 printf("DealType :%s\n",getLdapDealNetworkType($pDealer));
			 printf("DealDate :%s\n",getLdapDealNetworkDate($pDealer));
			 $i++;
			 $pDealer = getListDealNetworkElement($dealersList,$i);
			 }
			 //freeLdapPtrListDealNetwork($dealersList);
			 }
			 
			 if (isObjectNotNull($pUser)==1) {
			 $ArrRetour=array("login"=>"",
			 "why"=>"",
			 "user"=>array("id"=>getLdapUserUid($pUser),
			 "UserAgape"=>getLdapUserAgape ($pUser),
			 "name"=>getLdapUserLastName($pUser),
			 "firstname"=>getLdapUserFirstName($pUser),
			 "mail"=>getLdapUserMainMail ($pUser),
			 "workPlace"=>getLdapUserWorkPlaceLabel($pUser),
			 "tel"=>getLdapUserTelInt1($pUser),
			 "direction"=>getLdapUserDirection($pUser),
			 "fournisseur"=>getLdapUserExtCompany($pUser),
			 "CA"=>getLdapUserBudgetCenter($pUser),
			 "hierar"=>getLdapUserCodeUo($pUser),)
			 );
			 freeLdapPtrUser($pUser);
			 } else{
			 $ArrRetour=array("login"=>"", "why"=>"","user"=>array($p_sRPI, "", ""));
			 }
			 
			LDAPC_END();
		} else {
			//$ArrRetour=array("login"=>"", "why"=>"","user"=>array("", "", ""));
		}
		//return $ArrRetour;
		
	}
	
	public function getLDAPRoleList($p_sRPI)
	{
		error_reporting(E_ALL);
		LDAPC_NEW($this->sPropertiesFiles);
		$pUser  = findLdapUserByUid($p_sRPI);
		$roles = array();
		if ($roleList = getLdapUserRolesName($pUser))
		{
			$x = 0;
			while ($roleLibelle = getListCharElement($roleList, $x)) {
				$roles[] = $roleLibelle;
				$x++;
			}
		}
		if (count($roles) < 1)
		{
			$roles = false;
		}
		//echo "<pre>";
		//print_R($roles);
		return $roles;
	}
	
	public function getLDAPGroupList($p_sRPI)
	{
		$groups = array();
		LDAPC_NEW($this->sPropertiesFiles);
		$pUser  = findLdapUserByUid($p_sRPI);
		if ($groupList = findLdapUserGroups($pUser))
		{
			$x = 0;
			while ($groupLibelle = getListGroupElement($groupList, $x)) {
				$groups[] = getLdapGroupName($groupLibelle);
				$x++;
			}
		}
		
		if (count($groups) < 1)
		{
			$groups = false;
		}
		
		return $groups;
	}
	
	public function getRRDIFromLDAP($p_sRPI)
	{
		// MONOPASSPORT VERSION
		
		// $rrdiItems = array();
		
		// $passportElement = getLdapUserPassport($this->_pUser);
		// $rrdiList = getLdapPassportPsaRole($passportElement, "RRDI7");
		
		// $x = 0;
		// while ($rrdiItem = getListCharElement($rrdiList, $x))
		// {
		// $rrdiItems [] = $rrdiItem;
		// $x++;
		// }
		
		// if (count($rrdiItems) < 1)
		// {
		// $rrdiItems = false;
		// }
		
		//$pUser	= findLdapUserByUid($uid);
		$pUser = $uid;
		$p_sRPI = 'E498462';
		$pUser  = findLdapUserByUid($p_sRPI);
		$string = getLdapUserIdResp($pUser);
		printf("\t => getLdapUserIdResp     :%s\n", ($string)?$string:"NULL");exit;
		//echo $pUser;exit;
		if (isObjectNotNull($pUser))
		{
			PrintUser($pUser);
			echo("<H2>Liste des Entit�s adminisr�s hi�rarchiquement par $uid : </H2><BR>");
			
			
			$pSearchCriteria = initLdapSearchCriteria();
			
			$resCode = addLdapSearchCriteria($pSearchCriteria,SEARCH_CRITERIA_ORGUNIT_OWNER,getLdapUserDn($pUser),SEARCH_TYPE_EQUAL);
			$resCode &= addLdapSearchCriteria($pSearchCriteria,SEARCH_CRITERIA_VALIDITY,"ORGA_NP_NM",SEARCH_TYPE_EQUAL);
			$resCode &= addLdapSearchCriteria($pSearchCriteria,SEARCH_CRITERIA_VALIDITY,"ORGA",SEARCH_TYPE_EQUAL);
			
			if ($resCode)
			{
				
				$listEntities = findLdapEntitiesBySearchCriteria($pSearchCriteria);
				freeLdapSearchCriteria($pSearchCriteria);
			}
			else
			{
				$err = getLdapErrorMsg();
			}
			$i = 0;
			
			
			if (isObjectNotNull($listEntities))
			{
				
				$entity = getListEntitiesElement($listEntities,$i);
				while (isObjectNotNull($entity))
				{
					printEntity($entity);
					
					$i++;
					$entity = getListEntitiesElement($listEntities,$i);
				}
				freeLdapPtrListEntity($listEntities);
			}
			else
			{
				echo("<H2>Aucune</H2>");
			}
			
			freeLdapPtrUser($pUser);
		}
		// MULTIPASSPORT VERSION
		$p_sRPI = 'U394173';
		$pUser  = findLdapUserByUid($p_sRPI);
		$passportElements = getLdapUserPassports($pUser);
		$pUser1 = $pUser;
		
		//$pUser	= findLdapUserByUid($uid);
		
		
		if (isObjectNotNull($pUser))
		{
			
			// PrintUser($pUser);
			echo("<H2>Liste des Entit�s adminisr�s hi�rarchiquement par $uid : </H2><BR>");
			
			
			$pSearchCriteria = initLdapSearchCriteria();
			
			$resCode = addLdapSearchCriteria($pSearchCriteria,SEARCH_CRITERIA_ORGUNIT_OWNER,getLdapUserDn($pUser),SEARCH_TYPE_EQUAL);
		//	$resCode &= addLdapSearchCriteria($pSearchCriteria,SEARCH_CRITERIA_VALIDITY,"ORGA_NP_NM",SEARCH_TYPE_EQUAL);
		//	$resCode &= addLdapSearchCriteria($pSearchCriteria,SEARCH_CRITERIA_VALIDITY,"ORGA",SEARCH_TYPE_EQUAL);
			if ($resCode)
			{
				
				$listEntities = findLdapEntitiesBySearchCriteria($pSearchCriteria);
				
				print_R($listEntities);exit;
				freeLdapSearchCriteria($pSearchCriteria);
			}
			else
			{
				$err = getLdapErrorMsg();
			}
			$i = 0;
			
			
			if (isObjectNotNull($listEntities))
			{
				
				$entity = getListEntitiesElement($listEntities,$i);
				while (isObjectNotNull($entity))
				{
					printEntity($entity);
					
					$i++;
					$entity = getListEntitiesElement($listEntities,$i);
				}
				freeLdapPtrListEntity($listEntities);
			}
			else
			{
				echo("<H2>Aucune</H2>");
			}
			
			freeLdapPtrUser($pUser);
		}
// 		error_reporting(E_ALL);
// 		echo "123";
// 		$res = getLdapEntityParent($p_sRPI);
?> 

<table class='right' width="600">
            <TR>
            <TD colspan=2 align='center'><H2>Attributs utilisateur</H2></TD>
        </TR>
        <TR>
            <TD>Dn</TD><TD><?=getLdapUserDn($pUser1) ?></TD>
        </TR>
        
        <TR>
            <TD>UID</TD><TD><?=getLdapUserUid($pUser1) ?></TD>
        </TR>
                <TR>
            <TD>firstname</TD><TD><?=getLdapUserFirstName($pUser1)?></TD>
        </TR>
        <TR>
            <TD>lastname</TD><TD><?=getLdapUserLastName($pUser1)?></TD>
        </TR>
        <TR>
            <TD>lastname1</TD><TD><?=getLdapUserLastName1($pUser1)?></TD>
        </TR>
        <TR>
            <TD>lastname2</TD><TD><?=getLdapUserLastName2($pUser1)?></TD>
        </TR>
        <TR>
            <TD>locale</TD><TD><?=getLdapUserLocale($pUser1)?></TD>
        </TR>
        <TR>
            <TD>mail </TD><TD><?=getLdapUserMail($pUser1)?></TD>
        </TR>
        <TR>
            <TD>direction</TD><TD><?=getLdapUserDirection($pUser1)?></TD>
        </TR>
        <TR>
            <TD>agape</TD><TD><?=getLdapUserAgape($pUser1)?></TD>
        </TR>
        
            <TR>
            <TD>pays</TD><TD><?=getLdapUserPays($pUser1)?></TD>
        </TR>
        <TR>
            <TD>marque</TD><TD><?=getLdapUserMarque($pUser1)?></TD>
        </TR>
            <TR>
            <TD>ext1</TD><TD><?=getLdapUserTelExt1($pUser1)?></TD>
        </TR>
        <TR>
            <TD>ext2</TD><TD><?=getLdapUserTelExt2($pUser1)?></TD>
        </TR>
            <TR>
            <TD>int1</TD><TD><?=getLdapUserTelInt1($pUser1)?></TD>
        </TR>
        <TR>
            <TD>int2</TD><TD><?= getLdapUserTelInt2($pUser1)?></TD>
        </TR>
            <TR>
            <TD>IsResponsible</TD><TD><?=isLdapUserResponsibleOfUo($pUser1)?></TD>
        </TR>
            <TR>
            <TD>type</TD><TD><?=getLdapUserEmployeeType($pUser1)?></TD>
        </TR>
        <TR>
            <TD>Manager</TD><TD><?=getLdapUserOrganization($pUser1)?></TD>
        </TR>
        

<?php
		echo "here";
		print_r($res);exit;
		$x = 0;
		while ($passportElement = getListPassportElement($passportElements, $x))
		{
			$rrdiList = getLdapPassportPsaRole($passportElement, "RRDI7");
			$x = 0;
			while ($rrdiItem = getListCharElement($rrdiList, $x))
			{
				$rrdiItems [] = $rrdiItem;
				$x++;
			}
		}
		
		return $rrdiItems;
	}
	
}

?>
