<?php
/**
 * Req. Id      : REACH_RTM005
 * CAP-NO       : 19689
 * Class        : Spare_parts_model
 * Ddescription : Spare_parts_model Class to List all spare parts
 * @author      : Yogesh Pandey
 * @version     : 1.0
 */
  class Spare_parts_model extends CI_Model {
       
      public function __construct(){
          
        $this->load->database();
        
      }
      
    public function article_may_contain_txt($lang_code)
	{
		$this->db->from('tbl_ovl_text');
		$this->db->select('ovl_text');
		$this->db->join('tbl_language', 'tbl_language.id = tbl_ovl_text.lang_id');
		$this->db->where('tbl_language.lang_code', $lang_code);
		$query = $this->db->get();
		return $query->result(); 
	}
    //API call - get all spare_parts record
    public function getallspare_parts($spare_part_number){   

        $this->db->select('spare_part_number, brand, cas_number, substance_name, article_may_contain, status'); 

        $this->db->from('tbl_reach_data');
		
		$this->db->where("spare_part_number", $spare_part_number); 
		$this->db->where("status !=", '2');

        $this->db->order_by("id", "desc"); 

        $query = $this->db->get();

        if($query->num_rows() > 0){

          return $query->result_array();

        }else{

          return 0;

        }

    }
   


}