<?php
/**
 * Req. Id      : REACH_RTM010
 * CAP-NO       : 19689
 * Class        : Reach_regulation_edit_model
 * Ddescription : Reach_regulation_edit_model Class to update Reach Regulation inside DB
 * @author      : Yogesh Pandey
 * @version     : 1.0
 */
defined('BASEPATH') OR exit('No direct script access allowed');
 
    class Reach_regulation_edit_model extends CI_Model {
 
       function __construct() {
        parent::__construct(); 
        
    }
 

  
function add_reach_article($data)
    {   
	
	    $this->db->set($data);
		
        $res = $this->db->update('tbl_reach_article',$data);
		return $res;		
    }
function update_reach_article($data,$lang_id)
    {   
	
	    $this->db->set($data);
        $this->db->where('lang_id', $lang_id);		
        $res = $this->db->update('tbl_reach_article',$data);

		return $res;		
    }	
	
function get_reach_article($data)
    {  
/*	
for($i=0;$i<15000;$i++)
{
$data1 = array( 'spare_part_number' => 'J44AG'.$i.'17',
        'brand' => 'PCD',
        'cas_number' => '12626-81-2',
		'substance_name' => 'Lead titanium zirconium oxide',
		'article_may_contain' => '1',
		'status' => '1',
		'comment' => 'Bulk entry',
		'created_on' => date('Y-m-d H:i:s'),
		'updated_on' => date('Y-m-d H:i:s'),
		'updated_by' => 'E551997',
);

$this->db->insert('tbl_reach_data', $data1);
}
*/		
	    $query = $this
                ->db
                ->where('lang_id',$data)
                ->get('tbl_reach_article');

        if($query->num_rows()>0)
        {
            return $query->result(); 
        }
        else
        {
            return null;
        }		
   	

   }	

   }
?>