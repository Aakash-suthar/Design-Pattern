<?php
/**
 * Req. Id      : REACH_RTM005
 * CAP-NO       : 19689
 * Class        : Spare_list_model
 * Ddescription : Spare_list_model Class to List all spare parts
 * @author      : Yogesh Pandey
 * @version     : 1.0
 */
$_SESSION['session_name'] = '';

class Spare_list_model extends CI_Model{
	
	
    function __construct() {
        parent::__construct(); 
        
    }
	
    public function article_may_contain_txt($lang_code)
	{
		$this->db->from('tbl_ovl_text');
		$this->db->select('ovl_text');
		$this->db->join('tbl_language', 'tbl_language.id = tbl_ovl_text.lang_id');
		$this->db->where('tbl_language.lang_code', $lang_code);
		$query = $this->db->get();
		return $query->result(); 
	}
	
    public function allspare_parts_count()
    {  
        $role = $this->session->userdata('role');		
        if($role == 'ADMIN')
		{			
        $this->db->from('tbl_reach_data');
		$this->db->select('count(id) as `countrows`');		
    	$query = $this->db->get();
		}
		else
		{
		$this->db->from('tbl_reach_data');
		$this->db->select('count(id) as `countrows`');
        $this->db->where(' status != ', 2);		
    	$query = $this->db->get();
		}
        $count = $query->result();
        return $count[0]->countrows;   

    }
    
    public function allspare_parts($limit,$start,$col,$dir)
    {  
       $role = $this->session->userdata('role');	
       $limit = $this->security->xss_clean($limit);
       $start = $this->security->xss_clean($start);
       $col = $this->security->xss_clean($col);
       $dir = $this->security->xss_clean($dir);
	   $this->db->from('tbl_reach_data');
	   $this->db->select('id,spare_part_number,brand,cas_number,substance_name,article_may_contain,status');
	   /*************************************************
	    for admin only deleted records will be ignored
		*************************************************/
        if($role == 'ADMIN')
		{	   
       $query = $this->db->limit($limit,$start)->order_by($col,$dir)->get();
        }
		/*************************************************
	    for user only active & inactive records will be visible records will be ignored
		*************************************************/
		else
		{
			$query = $this->db->Where('status!=' , 2)->limit($limit,$start)->order_by($col,$dir)->get();
		}
        if($query->num_rows()>0)
        {
            return $query->result(); 
        }
        else
        {
            return null;
        }
        
    }
   
    public function spare_parts_search($limit,$start,$search,$col,$dir)
    { 
	   $role = $this->session->userdata('role');
	   $limit = $this->security->xss_clean($limit);
       $start = $this->security->xss_clean($start);
       $search = $this->security->xss_clean($search);
	   $rev_search = strrev($search);
	   $col = $this->security->xss_clean($col);
       $dir = $this->security->xss_clean($dir);	 
	   	/*************************************************
	    for admin only deleted records will be ignored
		*************************************************/
		$this->db->from('tbl_reach_data');
	    $this->db->select('id,spare_part_number,brand,cas_number,substance_name,article_may_contain,status');
	    if($role == 'ADMIN')
		{
        $query = $this->db->like('spare_part_number',$search,'after')->or_like('reverse_spare_part_number',$rev_search,'after')->limit($limit,$start)->get();
		}
		/*************************************************
	    for user only active & inactive records will be visible records will be ignored
		*************************************************/
		else
		{
			$query = $this->db->Where('status!=' , 2)->like('spare_part_number',$search,'after')->or_like('reverse_spare_part_number',$rev_search,'after')->limit($limit,$start)->get(); 
		}			
		
        
       
        if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return null;
        }
        
    }

    public function spare_parts_search_count($search)
    { 
	$role = $this->session->userdata('role');  
	$search = $this->security->xss_clean($search);
	$rev_search = strrev($search);
	/*************************************************
	    for admin only deleted records will be ignored
	*************************************************/
    if($role == 'ADMIN')
	{
		$this->db->from('tbl_reach_data');
		$this->db->select('count(id) as count');
		$this->db->like('spare_part_number',$search,'after')->or_like('reverse_spare_part_number',$rev_search,'after');
		//$this->db->where('spare_part_number like "%'.$search.'%"');
		
    	$query = $this->db->get();
    }
	/*************************************************
	    for user only active & inactive records will be visible records will be ignored
	*************************************************/	
	else
	{   
       $this->db->from('tbl_reach_data');
		$this->db->select('count(id) as `count`');
		$this->db->like('spare_part_number',$search,'after')->or_like('reverse_spare_part_number',$rev_search,'after');
		$this->db->where('status !=' , 2);
		$query = $this->db->get();
	}
		$res = $query->row();
        return $res->count;
    } 
   
}
	
	
?>