<?php
/**
 * Req. Id      : REACH_RTM007
 * CAP-NO       : 19689
 * Class        : Add_spare_part_model
 * Ddescription : Add_spare_part_model Class to add spare part using user interface into DB
 * @author      : Yogesh Pandey
 * @version     : 1.0
 */
defined('BASEPATH') OR exit('No direct script access allowed');
 
    class Add_spare_part_model extends CI_Model {
 
       function __construct() {
        parent::__construct(); 
        
    }
 

public function checkRecordExist($data) {	
/*************************************************
	 function to validate duplicate records
*************************************************/
$query = $this->db->query("SELECT *  FROM `tbl_reach_data`  Where spare_part_number ='".$data['spare_part_number']."' AND  cas_number = '".$data['cas_number']."' AND substance_name =  '".$data['substance_name']."' AND brand = '".$data['brand']."' ");

    $count_row = $query->num_rows();

    if ($count_row > 0) {
      //if count row return any row; that means you have already this email address in the database. so you must set false in this sense.
        return FALSE; // here I change TRUE to false.
     } else {
      // doesn't return any row means database doesn't have this email
        return TRUE; // And here false to TRUE
     }
}
  
public function add_spare_part($data)
    {   
/*************************************************
	 validate if record already present while adding
*************************************************/		
		if($this->checkRecordExist($data))
		{
	    $this->db->set($data);		
        $res = $this->db->insert('tbl_reach_data',$data);
		if($res)
		{
			return "1";
		}
		else
		{
			return "3";
		}
		}
        else
		{
			return "2";		
			
        }	
    }  
	

   }
?>