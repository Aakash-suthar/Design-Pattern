<?php
/**
 * Req. Id      : REACH_RTM001
 * CAP-NO       : 19689
 * Class        : Get_login_model
 * Ddescription : Get_login_model Class to get login details
 * @author      : Yogesh Pandey
 * @version     : 1.0
 */
$_SESSION['session_name'] = '';

class Get_login_model extends CI_Model{
	
	
    function __construct() {
        parent::__construct(); 
        
    }

    public function all_language()
    {   
       $this->db->from('tbl_language');
       $this->db->order_by("lang_label", "ASC");
	   $query = $this->db->get();
       return $query->result_array(); 

    }
	 public function get_lang_by($data)
    {   
		$query = $this
		->db
		->where("lang_code", $data)
		->get('tbl_language');
       return $query->result();  

    }
    public function get_lang_id_by($lang)
    {   
		$query = $this
		->db
		->where("lang_code", $lang)
		->get('tbl_language');

       return $query->result();  

    }
function get_country_name($where_array = array()){
		$res_array = array();
		$this->db->select('printable_name as country_name');
		$this->db->from('country');
		$this->db->where($where_array);
		$query= $this->db->get();
		if($query->num_rows() > 0)
		{
			$res_array =  $query->row_array();
		}
		return $res_array;		
	}
   
  
   
}
	
	
?>