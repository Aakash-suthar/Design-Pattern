<?php
/**
 * Req. Id      : REACH_RTM004
 * CAP-NO       : 19689
 * Class        : Export_model
 * Ddescription : Export_model Class to Export List of filtered records
 * @author      : Yogesh Pandey
 * @version     : 1.0
 */
defined('BASEPATH') OR exit('No direct script access allowed');
 
    class Export_model extends CI_Model {
 
       function __construct() {
        parent::__construct(); 
        
    }
        
		public function exportList($search,$col,$dir)
    {

        $query = $this
                ->db
				->select(array('spare_part_number','brand','cas_number','substance_name','article_may_contain','status','created_on','updated_on','updated_by','comment'))
                ->like('spare_part_number',$search)
                ->order_by($col,$dir)
				->limit('5000')
                ->get('tbl_reach_data');
        
       
        if($query->num_rows()>0)
        {
            return $query->result();  
        }
        else
        {
            return null;
        }
    }
        
    }
?>