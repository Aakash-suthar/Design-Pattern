<?php
/**
 * Req. Id      : REACH_RTM009
 * CAP-NO       : 19689
 * Class        : Import_model
 * Ddescription : Import_model Class to Import records inside DB
 * @author      : Yogesh Pandey
 * @version     : 1.0
 */
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Import_model extends CI_Model {
 
       function __construct() {
        parent::__construct(); 
        
    }

public function importList( $data ) {
	$data = $this->security->xss_clean($data);
	$table = 'tbl_reach_data';
	if( $data ['status'] == 3)
	{   
		$this->db->where('brand',$data ['brand']);
		$this->db->where('spare_part_number',$data ['spare_part_number']);
		$this->db->where('cas_number',$data ['cas_number']);
		$this->db->where('substance_name',$data ['substance_name']);
		$this->db->delete('tbl_reach_data');
	}
	else

{
    if (empty($table) || empty($data)) return false;
    $duplicate_data = array();
    foreach($data AS $key => $value) {
        $duplicate_data[] = sprintf("%s='%s'", $key, $value);
    }
/*************************************************
	 on duplicate update the record
*************************************************/
    $sql = sprintf("%s ON DUPLICATE KEY UPDATE %s", $this->db->insert_string($table, $data), implode(',', $duplicate_data));
    $this->db->query($sql);
}
    
    return $this->db->insert_id();
}
public function importListOVL( $data ) 
{      
$insert_query = $this->db->insert_string('tbl_reach_data',$data);
$insert_query = str_replace('INSERT INTO','INSERT IGNORE INTO',$insert_query);
$this->db->query($insert_query);
return $this->db->insert_id();	
}
public function importListOVL_batch( $data ) 
{      
$insert_query = $this->db->insert_ignore_batch('tbl_reach_data',$data);
return $this->db->insert_id();	
}
public function importListLog($data)
    {   
	    $data = $this->security->xss_clean($data);
	    $this->db->set($data);		
        $res = $this->db->insert('tbl_import_logs',$data);
		return $res;		
    }  

   }
?>