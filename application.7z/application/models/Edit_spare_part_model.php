<?php
/**
 * Req. Id      : REACH_RTM008
 * CAP-NO       : 19689
 * Class        : Edit_spare_part_model
 * Ddescription : Edit_spare_part_model Class to edit sapre part part details
 * @author      : Yogesh Pandey
 * @version     : 1.0
 */
defined('BASEPATH') OR exit('No direct script access allowed');
 
    class Edit_spare_part_model extends CI_Model {
 
       function __construct() {
        parent::__construct(); 
        
    }
 
public function checkRecordExistbyid($data,$id) {	
/*************************************************
	 function to validate duplicate records
*************************************************/		
$query = $this->db->query("SELECT *  FROM `tbl_reach_data`  Where spare_part_number ='".$data['spare_part_number']."' AND  cas_number = '".$data['cas_number']."' AND substance_name =  '".$data['substance_name']."' AND brand = '".$data['brand']."' AND id != ".$id);

    $count_row = $query->num_rows();

    if ($count_row > 0) {
      //if count row return any row; that means you have already this email address in the database. so you must set false in this sense.
        return FALSE; // here I change TRUE to false.
     } else {
      // doesn't return any row means database doesn't have this email
        return TRUE; // And here false to TRUE
     }
}
  
function edit_spare_part($data,$id)
    {   
	    if($data['status'] == 3)
		{
		$this->db->where('id', $id); 
	    $res = $this->db->delete('tbl_reach_data');
		if($res)
		{
		return "4";
		}
		else
		{
		return "5";
		}
		}
/*************************************************
	 validate if record already present while updating
*************************************************/	    	
	    if($this->checkRecordExistbyid($data,$id))
		{
	    $this->db->where('id', $id);
		$res = $this->db->update('tbl_reach_data', $data);
		
		 if($res)
		{
			return "1";
		}
		else
		{
			return "3";
		}
		}
        else
		{
			return "2";		
			
        }
		
			
    } 
function get_spare_part_info($data)
    {   
	    $query = $this
                ->db
                ->where('id',$data)
                ->get('tbl_reach_data');
        
        if($query->num_rows()>0)
        {
            return $query->result(); 
        }
        else
        {
            return null;
        }		
    } 	

   }
?>