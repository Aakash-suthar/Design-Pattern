<?php
/**
 * Req. Id      : REACH_RTM006
 * CAP-NO       : 19689
 * Class        : Export
 * Ddescription : Export Class to export list of spare parts
 * @author      : Yogesh Pandey
 * @version     : 1.0
 */
defined('BASEPATH') or exit('No direct script access allowed');

class Export extends CI_Controller
{
    // construct
    public function __construct()
    {
        parent::__construct();
        // load model
        $this
            ->load
            ->model('Export_model', 'export');
        $this
            ->load
            ->helper("security");

        $this
            ->load
            ->model('Get_login_model');
        $role = $this->session->userdata('role');
		$language = $this->session->userdata('language');
    	if(!isset($role) || $role == ''){
    		redirect('Logout');
    	}
        if (file_exists("system/language/" . strtolower($language) . "/" . strtolower($language) . "_lang.php"))
        {
            $this
                ->lang
                ->load($language, $language);
        }
        else
        {
              $language = 'en';
            $this
                ->lang
                ->load($language, $language);
        }
    }

    // create xlsx
    public function index()
    {
        // create file name
        $fileName = 'data-' . time() . '.xlsx';
        // load excel library
        $this
            ->load
            ->library('excel');
        $col = 'id';
        $dir = 'desc';
        $search = $this
            ->session->spare_part_no;
        $listInfo = $this
            ->export
            ->exportList($search, $col, $dir);
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->setActiveSheetIndex(0);
        // set Header
        $objPHPExcel->getActiveSheet()
            ->SetCellValue('A1', 'NAME');
        $objPHPExcel->getActiveSheet()
            ->SetCellValue('B1', "REACH_DATA_" . date("d-m-Y") . ".xlsx");
        $objPHPExcel->getActiveSheet()
            ->SetCellValue('C1', 'FILTERS');
        $objPHPExcel->getActiveSheet()
            ->SetCellValue('C2', 'Spare Part number');
        $objPHPExcel->getActiveSheet()
            ->SetCellValue('D2', $search);
        $objPHPExcel->getActiveSheet()
            ->SetCellValue('D5', 'Substance Number');
        $objPHPExcel->getActiveSheet()
            ->SetCellValue('A5', 'Spare Part Number');
        $objPHPExcel->getActiveSheet()
            ->SetCellValue('B5', 'Brand');
        $objPHPExcel->getActiveSheet()
            ->SetCellValue('C5', 'CAS Number');
        $objPHPExcel->getActiveSheet()
            ->SetCellValue('D5', 'Substance Number');
        /*************************************************
        ADMIN can view extra info. in exported data
        *************************************************/
        if ($this
            ->session
            ->userdata('role') == 'ADMIN')
        {
            $objPHPExcel->getActiveSheet()
                ->SetCellValue('E5', 'Article May Contain');
            $objPHPExcel->getActiveSheet()
                ->SetCellValue('F5', 'Status');
            $objPHPExcel->getActiveSheet()
                ->SetCellValue('G5', 'Created On');
            $objPHPExcel->getActiveSheet()
                ->SetCellValue('H5', 'Updated On');
            $objPHPExcel->getActiveSheet()
                ->SetCellValue('I5', 'Updated By');
            $objPHPExcel->getActiveSheet()
                ->SetCellValue('J5', 'Comment');

        }
        // set Row
        $rowCount = 6;
        foreach ($listInfo as $list)
        {
            if ($list->status == '1')

            {
                $status = 'Active';
            }
            else
            {
                $status = 'Inactive';
            }
            $objPHPExcel->getActiveSheet()
                ->SetCellValue('A' . $rowCount, $list->spare_part_number);
            $objPHPExcel->getActiveSheet()
                ->SetCellValue('B' . $rowCount, $list->brand);
            $objPHPExcel->getActiveSheet()
                ->SetCellValue('C' . $rowCount, $list->cas_number);
            $objPHPExcel->getActiveSheet()
                ->SetCellValue('D' . $rowCount, $list->substance_name);
            /*************************************************
            ADMIN can view extra info. in exported data
            *************************************************/
            if ($this
                ->session
                ->userdata('role') == 'ADMIN')
            {
                $objPHPExcel->getActiveSheet()
                    ->SetCellValue('E' . $rowCount, $list->article_may_contain);
                $objPHPExcel->getActiveSheet()
                    ->SetCellValue('F' . $rowCount, $status);
                $objPHPExcel->getActiveSheet()
                    ->SetCellValue('G' . $rowCount, $list->created_on);
                $objPHPExcel->getActiveSheet()
                    ->SetCellValue('H' . $rowCount, $list->updated_on);
                $objPHPExcel->getActiveSheet()
                    ->SetCellValue('I' . $rowCount, $list->updated_by);
                $objPHPExcel->getActiveSheet()
                    ->SetCellValue('J' . $rowCount, $list->comment);
            }
            $rowCount++;
        }
        $filename = "REACH_DATA_" . date("d-m-Y") . ".xlsx";
        // Redirect output to a client’s web browser (Excel5)
        header('Content-Type: application/vnd.openxmlformats-office/.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');

    }

}
?>
