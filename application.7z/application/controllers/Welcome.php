<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct(){
		
		parent::__construct();
		
		$method = $this->router->fetch_method();
		$this->load->helper('url');		
		$this->load->model('Get_login_model');
		
		if($method == 'index'){
			$this->user_login();exit;
		}
		
	} 
	
	public function index()
	{
		redirect('no_access');exit;
	}
	
	public function user_login(){
		    $requestUri = $_SERVER['QUERY_STRING']; 
		if ($requestUri != "") {
			$url = $this->decrypt($requestUri);
			$language 	= substr($url,0,2);
			$language 	= strtolower($language);
			$country 	= substr($url,2,2);
			$repairer 	= substr($url,4,7);
			$brand 		= substr($url,11,2);
			$dealer 	= substr($url,27,7);
			$time = substr($url, 13, 14);
			
			$time = date('Y-m-d H:i:s', strtotime($time));
			$expiryTime = 60 * 60 * 60;
			if ((strtotime($time) + $expiryTime) < time()) {
				$var = $this->load->view('errors/403.php');	
				exit();
			}
			
			$url_pos = strpos($url,'http');
			$url_end_pos = strpos($url,'.do'); 
            $url_length = ($url_end_pos - $url_pos)+3;
			$panier_url = substr($url,$url_pos,$url_length);			
			// Save data in session
			$this->session->set_userdata('language',$language);
			$this->session->set_userdata('country',$country);
			$this->session->set_userdata('repairer',$repairer);
			$this->session->set_userdata('user_id',$repairer);
			$this->session->set_userdata('role', 'ADMIN');
			$this->session->set_userdata('brand',$brand);
			$this->session->set_userdata('dealer',$dealer);
			$this->session->set_userdata('panier_url',$panier_url);
            $language_label = '';
			$language_arr = $this->Get_login_model->get_lang_by($language);
			if($language_arr)
			{
				$language_label = ucwords($language_arr[0]->lang_label);
			}
			else
			{
				$this->session->set_userdata('language','en');
				 $language_label = 'English';
			}
			if($this->session->userdata('language') != '' && $this->session->userdata('country') != '' && $this->session->userdata('repairer') != ''  && $this->session->userdata('brand') != ''  && $this->session->userdata('dealer') != ''   && $this->session->userdata('panier_url') != '' && $language_label != '' ){				
				
			
				redirect('Reach_Regulation');
			} else {
				
				// Display Page not Found Page
				$this->load->view('errors/404.php');				
				exit;
			}
			
		}else{
			if (!isset($_SERVER['PHP_AUTH_USER'])) {
				$this->show_login_header();
				if(strpos($_SERVER['HTTP_USER_AGENT'], 'Trident/7')){
					$this->user_login();
				}
			} else {
				$this->session->set_userdata('language','en');
				$this->session->set_userdata('language_lable','English');
				unset($_SESSION['userid']);
				$userId = $_SERVER['PHP_AUTH_USER'];
				$password= $_SERVER['PHP_AUTH_PW'];
				
				$this->load->library('Class_ldapc');				
				$objLDAP = new class_ldapc("application/libraries/ldap.properties");
				
				$identity = $objLDAP->lookInLdapcIdentify ( $userId, $password );
				
				if ($identity ['login'] == "granted") {
					$grouplist = $objLDAP->getLDAPGroupList($userId);
					if(!in_array('REA.ADMIN',$grouplist)){
						redirect('No_access');
						exit;
					}else{
						$infos = $objLDAP->test_lookInLdapcInfos( $userId );
						$country_data = $this->Get_login_model->get_country_name(array('iso'=>strtoupper($infos['pays'])));
						$country_name = $infos['pays'];
						if(!empty($country_data)){
							$country_name = $country_data['country_name'];
						}
						$this->session->set_userdata('isLoggedIn', true);
						$this->session->set_userdata('rrdi',$userId);
						$this->session->set_userdata('user_id',$userId);
						$this->session->set_userdata('language','en');
						$this->session->set_userdata('country',$country_name); 
						$this->session->set_userdata('role', 'ADMIN');
						//$lang = 
						$language = 'en';
						$language_label = '';
			            $language_arr = $this->Get_login_model->get_lang_by($language);
						if(file_exists("system/language/".strtolower($language)."/".strtolower($language)."_lang.php"))
						{  
					        
							$this->lang->load($language,$language);
							
						}
						else
						{
							$language	= strtolower($this->config->item('DEFAULT_LANG'));
							$this->lang->load($language,$language);
						}
						
						redirect(Reach_Regulation);
						exit;
					}
				}else{
					$_SESSION['userid'] = 1;
					$this->show_login_header();
				}
			}
		}
	}
	
	public function show_login_header(){
		header('WWW-Authenticate: Basic realm="Inetpsa"');
		header('HTTP/1.0 401 Unauthorized');
		
	}
	
	
	
	public function decrypt($chaine)
    {
		
    	$result = $this->launchRot13($chaine);

    	$baseDecode = base64_decode($result); 

    	return  $this->launchRot13($baseDecode); 
    	 

    } 
public function launchRot13($chaine)
    {
    	$result = "";
    	for($i=0;$i < strlen($chaine);$i++) {
    		$result = $result.$this->rot13One($chaine[$i]); 
    	}
    	return $result; 
    } 
public function rot13One($ch)
    {
    	$valeur = ord($ch[0]); 
    	$max = 0;
    	$min = 0; 
    	$rot = 0;
    	if (($valeur > 96) && ($valeur <123)) {
				// minuscule
    		$max = 122;
    		$min = 96;
    		$rot = 13;
    	} else if(($valeur > 64) && ($valeur < 91)) {
				// majuscule
    		$max = 90;
    		$min = 64;
    		$rot = 13;
    	} else if (($valeur > 47) && ($valeur < 58)) {
    		$max = 57; 
    		$min = 47;
    		$rot = 5;
    	}
    	$valeur = $valeur+$rot;
    	if ($valeur > $max) {
    		$valeur = $min + ($valeur - $max); 
    	}
    	return chr($valeur);
    } 
 

	
}
