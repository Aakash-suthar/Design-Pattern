<?php
/**
 * Req. Id      : REACH_RTM012
 * CAP-NO       : 19689
 * Class        : ReachWebService
 * Ddescription : ReachWebService Class to connect and provide spare parts details to FDZ
 * @author      : Yogesh Pandey
 * @version     : 1.0
 */
require (APPPATH . '/libraries/REST_Controller.php');

class ReachWebService extends REST_Controller
{

    public function __construct()
    {

        parent::__construct();

        $this
            ->load
            ->model('Spare_parts_model');
			
		$this->load->helper("security");	
       
       
     
    }

    //API -  Fetch All spare_partss
    function spare_parts_post()
    {    
	    $language = $this->security->xss_clean($this->post('user_language'));
	    
		
		  if (!file_exists("system/language/" . strtolower($language) . "/" . strtolower($language) . "_lang.php"))
        {
            $language = 'en';
        }
		
        $salt = $this->config->item('salt');
        $spare_part_number = $this->security->xss_clean($this->post('spare_part_number'));
        $user_name = $this->security->xss_clean($this->post('user_name'));
        $password = $this->security->xss_clean($this->post('password'));
        $hashvalue = MD5(trim($user_name . $salt));

       
			
			header('Content-Type: application/json');
			
        if ($hashvalue == $password)
        {
			 $new_array = $this
            ->Spare_parts_model
            ->getallspare_parts($spare_part_number);
			
		$result1 = array();	
		$result = array();	
		
		if(isset($new_array) && $new_array != 0)
		{
			$article_may_txt = $this->Spare_parts_model->article_may_contain_txt($language);
			foreach($new_array as $res)
			{
				if ($res['article_may_contain'] == '1')
				{
					$res['substance_name'] = $article_may_txt[0]->ovl_text.' : '.$res['substance_name'];
				}
				
				
				unset($res['article_may_contain']);
				unset($res['status']);
				unset($res['spare_part_number']);
				unset($res['brand']);
				
				$result1[] = $res;
			}
			$result["spare_part_reference_number"] = $spare_part_number;
			$result["user_language"] = $language;
			$result['reach_data'] = $result1;
            if ($result)
            {

                $this->response($result, 200);

            }
		}
		else
            {

                $this->response("No record found", 404);

            }

            
        }
        else
        {
            $this->response('Unauthorized Access', 401);
        }
    }

}

