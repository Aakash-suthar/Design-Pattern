<?php
/**
 * Req. Id      : REACH_RTM009
 * CAP-NO       : 19689
 * Class        : Import
 * Ddescription : Import Class to Add & update spare parts
 * @author      : Yogesh Pandey
 * @version     : 1.0
 */
defined('BASEPATH') or exit('No direct script access allowed');

class Import extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this
            ->load
            ->helper('url');
        $this
            ->load
            ->helper("security");
        $this
            ->load
            ->model('Import_model', 'import');
        $this
            ->load
            ->model('Get_login_model');
        $role = $this->session->userdata('role');
    	if(!isset($role) || $role == ''){
    		redirect('Logout');
    	}
        /*************************************************
        Set default language english if language not set
        *************************************************/
        if ($this
            ->session
            ->userdata('language') != '')
        {
            $language = $this
                ->session
                ->userdata('language');
        }
        else
        {
            $language = 'en';
        }
        if (file_exists("system/language/" . strtolower($language) . "/" . strtolower($language) . "_lang.php"))
        {
            $this
                ->lang
                ->load($language, $language);
        }
        else
        {
              $language = 'en';
			  
            $this
                ->lang
                ->load($language, $language);
        }

        $role = $this
            ->session
            ->userdata('role');

        if ($role != 'ADMIN')
        {
            redirect('Reach_Regulation');
            exit;
        }
		
		//echo '<br> start time '.date('Y-m-d H:i:s');
    }
    public function import_validation($case, $value)
    {

        switch ($case)
        {
            case 'spare_part_number':
                if (empty($value))
                {
                    $spare_error = "Spare Part Number can not be empty";
                }
                else if (strlen($value) > 50)
                {
                    $spare_error = "Spare Part Number can not be greater than 50";
                }
                else
                {
                    $spare_error = 'valid';
                }
                return $spare_error;
                break;
            case 'cas_number':
                if (strlen($value) > 11)
                {
                    $cas_Error = "CAS Number can not be greater than 11";
                }
                else
                {
                    $cas_Error = 'valid';
                }
                return $cas_Error;
                break;
            case 'brand':
                if (strlen($value) > 10)
                {
                    $brand_Error = "Brand can not be greater than 10";
                }
                else
                {
                    $brand_Error = 'valid';
                }
                return $brand_Error;
                break;
            case 'substance_name':
                if (empty($value))
                {
                    $substance_Error = "Substance Name can not be empty";
                }
                else
                {
                    $substance_Error = 'valid';
                }
                return $substance_Error;
                break;
            case 'status':
                if ((strlen($value) == 0))
                {
                    $status_Error = "Status can not be empty";
                }
                else if (strlen($value) > 10)
                {
                    $status_Error = "Status can not be greater than 10";
                }
                else
                {
                    $status_Error = 'valid';
                }
                return $status_Error;
                break;
            case 'article_may_contain':
                if (empty($value))
                {
                    $article_Error = "Article may contain can not be empty";
                }
                else if (strlen($value) > 1)
                {
                    $article_Error = "Article may contain can not be greater than 1";
                }
                else
                {
                    $article_error = 'valid';
                }
                return $article_error;
                break;

            }
        }

        public function index()
        {
            $data['maincontent'] = 'includes/header_cmn';
            $data['footercontent'] = 'includes/footer_cmn';
            $data['url'] = $this
                ->uri
                ->segment(1);
            $data['url2'] = $this
                ->uri
                ->segment(2);
            $this
                ->load
                ->view('Import_Data', $data);
            $this
                ->load
                ->library('excel');
        }
		/*************************************************
        Data import - to save or update data using PCD or OVL format
        *************************************************/
		 /**
                    * 
                    * Data Import
                    *
                    * @param string $file_name  description
                    * @param string $new_name  description
                    * @param integer $new_width  description
                    * @param integer $new_height  description
                    * @param string $directory  description
                    * @return string
                    
             */
        public function upload()
        {
             
			 
			$file = $this->security->xss_clean($_FILES); 
            $file_info = pathinfo($file["inputGroupFile01"]["name"]);                      
            $allowedExts = array(
                "xlsx"
            );
            $extension = pathinfo($file["inputGroupFile01"]["name"], PATHINFO_EXTENSION);
			$finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mimetype =  finfo_file($finfo, $file['inputGroupFile01']['tmp_name']);
			$filesize =  $file['inputGroupFile01']['size'];
			$Max_Size_allow = 1024 * 1024 * 20; // 20 MB
			
            /*************************************************
            check valid extension allowed
            *************************************************/
			$error = '';
            if (!in_array($extension, $allowedExts))
            {
                $this
                    ->form_validation
                    ->set_message('validate_image', "Invalid file extension {$extension}");
                $error =  'Invalid File Extension';
                
            }
			if($mimetype != 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
			{
				$error =  'Invalid File Format';
				
			}
			if($filesize > $Max_Size_allow)
			{
				$error =  'File size is greater than max allowed size';
			}
			 
			if(isset($error) && strlen($error) > 1)
			{				
			$temp_var = date('Y-m-d H_i_s');
                    $file_name = 'upload/import_errors_' . $temp_var . '.csv';
                    $fp = fopen($file_name, 'w');
                    fputcsv($fp, array(
                        'Row No',
                        'Error Message'
                    ));
                    
                    fputcsv($fp, array(
                            '1',
                            $error
                        ));                   
                    fclose($fp);
					echo  $file_name;
					exit;
			}
            
            $this
                ->load
                ->library('excel');

            $inputFile = $this
                ->security
                ->xss_clean($file['inputGroupFile01']['name']);
            $inputFileName = $this
                ->security
                ->xss_clean($file['inputGroupFile01']['tmp_name']);
            $file_type = PHPExcel_IOFactory::identify($inputFileName);
            $objReader = PHPExcel_IOFactory::createReader($file_type);
            $objPHPExcel = $objReader->load($inputFileName);
            $excel = PHPExcel_IOFactory::load($inputFileName);
            $sheetCount = $excel->getSheetCount();
            /*************************************************
            if sheet count is greater than means its ov format
            *************************************************/
            if ($sheetCount > 1) // OV data import sheet
            
            {
                $sheet_data1 = $objPHPExcel->setActiveSheetIndex(0)
                    ->toArray(null, true, true, true);
                $sheet_data = $objPHPExcel->setActiveSheetIndex(1)
                    ->toArray(null, true, true, true);
                $i = 0;
				$j = 0;
				$k = 1;
                $errorlist = array();
                $spare_info_array = $sheet_data1[1];
                $spare_info = $spare_info_array['C'];
                $info = explode(':', $spare_info);
                $cas_no = $info[3];
                $substance_contain = str_replace("Article may contain ", "", $info[1]);
                $article_may_contain = '1';
                $error_array = array();
                $final_import = array();
				$cas_number = trim($cas_no);
                $substance_name = trim($substance_contain);
               
                        /*************************************************
                        For OV format Deafult alue for article mat contain will be 1
                        *************************************************/
					    $brand = 'OVL';
                        $status = '1';
                        $article_may_contain = rtrim($article_may_contain);
                        $created_on = date('Y-m-d H:i:s');
                        $updated_on = date('Y-m-d H:i:s');
                        $updated_by = $this
                            ->session
                            ->userdata('user_id');				
						$cas_response = $this->import_validation('cas_number', $cas_number);
						$subs_response = $this->import_validation('substance_name', $substance_name);
						
				//echo '<br> Step 1'.date('Y-m-d H:i:s');		
                foreach ($sheet_data as $data)
                {
                    $myarray = array();
					
                        /*************************************************
                        For OV format Deafult alue for article mat contain will be 1
                        *************************************************/
						$myarray['brand'] = $brand;
						$myarray['cas_number'] = $cas_number;
						$myarray['substance_name'] = $substance_name;						
                        $myarray['status'] = $status;
                        $myarray['article_may_contain'] =$article_may_contain;
                        $myarray['created_on'] = $created_on;
                        $myarray['updated_on'] = $updated_on;
                        $myarray['updated_by'] = $updated_by;		
                    $i++;
					$j++;
					
                    if ($i > 1)
                    {
                        $myarray['spare_part_number'] = rtrim($data['A']);
						$myarray['reverse_spare_part_number'] = strrev($myarray['spare_part_number']);
                        if ($myarray['spare_part_number'] != '' || $myarray['cas_number'] != '' || $myarray['substance_name'] != '')
                        {
                            $response = $this->import_validation('spare_part_number', $myarray['spare_part_number']);
                            if ($response != 'valid')
                            {
                                $error_array[$i] = $response;
                            }
                            
                            if ($cas_response != 'valid')
                            {
                                $error_array[$i] = $cas_response;
                            }
							if ($subs_response != 'valid')
                            {
                                $error_array[$i] = $subs_response;
                            }
                            
                            //$final_import[] = array($myarray['spare_part_number'],$brand,$cas_number,$substance_name,$article_may_contain,$status,$created_on,$updated_on, $updated_by);
                            array_push($final_import, $myarray);
                        }
                    }
                }
               // echo '<br> Step 2'.date('Y-m-d H:i:s');	
                if (empty($error_array))
                {   
			     
                    //echo '<br> count of elements in array '.count($final_import);
					$_datas = array_chunk($final_import, 50000);
					foreach ($_datas as $data) {					
					$listInfo = $this
                            ->import
                            ->importListOVL_batch($data);
					}
					//echo '<br> Step 3'.date('Y-m-d H:i:s');	
					
                   /* foreach ($final_import as $data_arr)
                    {   
                        $myarray = array();
						$myarray['spare_part_number'] = $data_arr;
						$myarray['brand'] = $brand;
						$myarray['cas_number'] = $cas_number;
						$myarray['substance_name'] = $substance_name;						
                        $myarray['status'] = $status;
                        $myarray['article_may_contain'] =$article_may_contain;
                        $myarray['created_on'] = $created_on;
                        $myarray['updated_on'] = $updated_on;
                        $myarray['updated_by'] = $updated_by;
						
                        $myarray = $this
                            ->security
                            ->xss_clean($myarray);
                        $listInfo = $this
                            ->import
                            ->importListOVL($myarray);
                    } */
                    
                    if (isset($listInfo))
                    {

                        $temp = explode(".", $inputFile);
                        $newfilename = $temp[0] . '_' . date('Y-m-d-H_i_s') . '.' . end($temp);
                        move_uploaded_file($inputFileName, $_SERVER['DOCUMENT_ROOT']."/upload/" . $newfilename);
                        $myLogarray = array(
                            'import_filename' => $newfilename,
                            'import_by' => $this
                                ->session
                                ->userdata('user_id') ,
                            'imported_on' => date('Y-m-d H:i:s')
                        );
                        $listInfo = $this
                            ->import
                            ->importListLog($myLogarray);
						//echo '<br> end time '.date('Y-m-d H:i:s');
                        echo 'success';
						exit;
                    }
                    else
                    {
                        echo 'fail';
						exit;
                    }
                }
                else
                {   
					 $temp_var = date('Y-m-d H_i_s');
                    $file_name = 'upload/import_errors_' . $temp_var . '.csv';
                    $fp = fopen($file_name, 'w');
                    fputcsv($fp, array(
                        'Row No',
                        'Error Message'
                    ));
                    foreach ($error_array as $row => $val)
                    {
                        $str = ltrim($val, ',');
                        fputcsv($fp, array(
                            $row,
                            $str
                        ));
                    }
                    fclose($fp);
                    echo $file_name;

                }

            }
            /*************************************************
            PCD Excel Format
            *************************************************/
            else
            // Rech data import sheet
            
            {
                $sheet_data = $objPHPExcel->getActiveSheet()
                    ->toArray(null, true, true, true);
                $i = 0;
                $errorlist = array();
                $error_array = array();
                $final_import = array();
                foreach ($sheet_data as $data)
                {
                    $i++;
                    if ($i > 1)
                    {

                        $myarray = array();
                        $myarray['spare_part_number'] = rtrim($data['A']);
						$myarray['reverse_spare_part_number'] = strrev($myarray['spare_part_number']);
                        $myarray['cas_number'] = rtrim($data['B']);
                        $myarray['substance_name'] = rtrim($data['C']);
                        $myarray['brand'] = rtrim($data['D']);
						if($myarray['brand'] == '')
						{
						$myarray['brand'] = 'PCD';
						}
                        /*************************************************
                        For PCD format Deafult alue for article mat contain will be 0
                        *************************************************/
                        if (rtrim($data['G']) != '1')
                        {
                            $myarray['article_may_contain'] = 0;
                        }
                        else
                        {
                            $myarray['article_may_contain'] = rtrim($data['G']);
                        }
                        $myarray['comment'] = rtrim($data['F']);
                        $myarray['created_on'] = date('Y-m-d H:i:s');
                        $myarray['updated_on'] = date('Y-m-d H:i:s');
                        $myarray['updated_by'] = $this
                            ->session
                            ->userdata('user_id');
                        $status = rtrim($data['E']);

                        if ($status == 'Active')
                        {
                            $myarray['status'] = '1';
                        }
                        else if ($status == 'In active')
                        {
                            $myarray['status'] = '0';
                        }
                        else if ($status == 'Substituted')
                        {
                            $myarray['status'] = '2';
                        }
                        else if ($status == 'Deleted')
                        {
                            $myarray['status'] = '3';
                        }
                        else
                        {
                            $myarray['status'] = NULL;
                        }

                        if ($myarray['spare_part_number'] != '' || $myarray['cas_number'] != '' || $myarray['substance_name'] != '')
                        {
                            $response = $this->import_validation('spare_part_number', $myarray['spare_part_number']);
                            if ($response != 'valid')
                            {
                                $error_array[$i] = $response;
                            }
                            $response = $this->import_validation('cas_number', $myarray['cas_number']);
                            if ($response != 'valid')
                            {
                                $error_array[$i] = $response;
                            }
                            $response = $this->import_validation('substance_name', $myarray['substance_name']);
                            if ($response != 'valid')
                            {
                                $error_array[$i] = $response;
                            }
                            $response = $this->import_validation('brand', $myarray['brand']);
                            if ($response != 'valid')
                            {
                                $error_array[$i] = $response;
                            }
                            $response = $this->import_validation('status', $myarray['status']);
                            if ($response != 'valid')
                            {
                                $error_array[$i] = $response;
                            }

                            array_push($final_import, $myarray);

                        }

                    }

                }
                if (empty($error_array))
                {
					
                    foreach ($final_import as $myarray)
                    {
                        $myarray = $this
                            ->security
                            ->xss_clean($myarray);
                        $listInfo = $this
                            ->import
                            ->importList($myarray);
                    }

                    if (isset($listInfo))
                    {

                        $temp = explode(".", $inputFile);
					    $xtn = end($temp);
                        $newfilename = $temp[0] . '_' . date('Y-m-d-H_i_s') . '.' . end($temp);
						if (!in_array(end($temp), $allowedExts))
            {
				$this
                    ->form_validation
                    ->set_message('validate_image', "Invalid file extension {$xtn}");
                echo 'invalid_extension';
                exit;
			}
			else{
				       
                        move_uploaded_file($inputFileName, $_SERVER['DOCUMENT_ROOT']."/upload/" . $newfilename);
                        $myLogarray = array(
                            'import_filename' => $newfilename,
                            'import_by' => $this
                                ->session
                                ->userdata('user_id') ,
                            'imported_on' => date('Y-m-d H:i:s')
                        );
                        $listInfo = $this
                            ->import
                            ->importListLog($myLogarray);
                        echo 'success';
			}
                    }
                    else
                    {
                        echo 'fail';
                    }
                }
                else
                {
                    /*************************************************
                    If there is any error in imported sheet it will export error
                    *************************************************/
                    $temp_var = date('Y-m-d H_i_s');
                    $file_name = 'upload/import_errors_' . $temp_var . '.csv';
                    $fp = fopen($file_name, 'w');
                    fputcsv($fp, array(
                        'Row No',
                        'Error Message'
                    ));
                    foreach ($error_array as $row => $val)
                    {
                        $str = ltrim($val, ',');
                        fputcsv($fp, array(
                            $row,
                            $str
                        ));
                    }
                    fclose($fp);

                    echo $file_name;
                }

            }

        }
        public function import()
        {
            $data['maincontent'] = 'includes/header_cmn';
            $data['footercontent'] = 'includes/footer_cmn';
            $this
                ->load
                ->view('import_data.php', $data);
        }

    }
    
 