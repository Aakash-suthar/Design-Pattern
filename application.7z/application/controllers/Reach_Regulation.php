<?php
/**
 * Req. Id      : REACH_RTM002
 * CAP-NO       : 19689
 * Class        : Reach_Regulation
 * Ddescription : Reach_Regulation Class to update and display reach regulation
 * @author      : Yogesh Pandey
 * @version     : 1.0
 */
defined('BASEPATH') or exit('No direct script access allowed');

class Reach_Regulation extends CI_Controller
{
    public function __construct()
    {

        parent::__construct();

        $this
            ->load
            ->helper('url');
        $this
            ->load
            ->helper("security");
        $this
            ->load
            ->model('Get_login_model');
        $this
            ->load
            ->model('Reach_regulation_edit_model', 'edit_regulation');
        $role = $this->session->userdata('role');
    	if(!isset($role) || $role == ''){
    		redirect('Logout');
    	}
        /*************************************************
        Set default language english if language not set
        *************************************************/
		
        if ($this
            ->session
            ->userdata('language') != '')
        {
            $language = $this
                ->session
                ->userdata('language');
        }
        else
        {
            $language = 'en';
        }
		
        if (file_exists("system/language/" . strtolower($language) . "/" . strtolower($language) . "_lang.php"))
        {
            $this
                ->lang
                ->load($language, $language);
        }
        else
        {
            $language = 'en';
				
            $this
                ->lang
                ->load($language, $language);
        }

    }

    public function index()
    {
        $data['maincontent'] = 'includes/header_cmn';
        $data['footercontent'] = 'includes/footer_cmn';
        if ($this
            ->session
            ->userdata('language') != '')
        {
            $language = $this
                ->session
                ->userdata('language');
        }
        else
        {
            $language = 'en';
        }

        $lang_id = $this
            ->Get_login_model
            ->get_lang_id_by($language);
        /*************************************************
        GET reach regulation in specific language
        *************************************************/
        $result = $this
            ->edit_regulation
            ->get_reach_article($lang_id[0]->id);
        $result = $result[0];
        $data['reach_regulation_text'] = $result->reach_regulation_text;
        $data['url'] = $this
            ->uri
            ->segment(1);
        $data['url2'] = $this
            ->uri
            ->segment(2);
        $data['lang_id'] = $lang_id[0]->id;
        $this
            ->load
            ->view('Reach_Regulation_info', $data);

    }
    /*************************************************
     update reach regulation in specific language 
    *************************************************/
	/**
                * 
                * update reach regulation
                *
                * @param string $file_name  description
                * @param string $new_name  description
                * @param integer $new_width  description
                * @param integer $new_height  description
                * @param string $directory  description
                * @return boolean
                
         */
    public function save()
    {
        
        if ($this
            ->session
            ->userdata('language') != '')
        {
            $language = $this
                ->session
                ->userdata('language');
        }
        else
        {
            $language = 'en';
        }
        $lang_id = $this
            ->Get_login_model
            ->get_lang_id_by($language);
        /*************************************************
        Get Language ID to be updated
        *************************************************/
        $lang_id = $lang_id[0]->id;
        $data = array(
            'lang_id' => $lang_id,
            'reach_regulation_text	' => $this
                ->input
                ->post('editor_data') ,
            'updated_on' => date('Y-m-d h:i:s') ,
            'updated_by' => $this
                ->session
                ->userdata('user_id')
        );
        $data = $this
            ->security
            ->xss_clean($data);
        $res = $this
            ->edit_regulation
            ->update_reach_article($data, $lang_id);

        if ($res)
        {
            echo 'success';
        }
        else
        {
            echo 'fail';
        }

    }
}

