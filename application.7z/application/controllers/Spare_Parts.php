<?php
/**
 * Req. Id      : REACH_RTM003
 * CAP-NO       : 19689
 * Class        : Spare_Parts
 * Ddescription : Spare_Parts Class to List all spare parts
 * @author      : Yogesh Pandey
 * @version     : 1.0
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class Spare_Parts extends CI_Controller {
 public function __construct()
    {   
        parent::__construct();
		$this->load->helper('url');
		$this->load->helper("security");
		$this->load->model('Spare_list_model','spare_list');
	
		$this->load->library('encryption');
		$this->load->model('Get_login_model');
		$role = $this->session->userdata('role');
    	if(!isset($role) || $role == ''){
    		redirect('Logout');
    	}
		/*************************************************
	    Set default language english if language not set 
		*************************************************/
		if($this->session->userdata('language')!='')
		{
		$language = $this->session->userdata('language');
		}
		else
		{
		$language = 'en';
		}
		
		if(file_exists("system/language/".strtolower($language)."/".strtolower($language)."_lang.php"))
		{
			$this->lang->load($language,$language);
		}
		else
		{
			$language	= 'en';
			$this->lang->load($language,$language);
		}
		$role = $this->session->userdata('role');
    }

	public function index()
	{   $data['maincontent'] = 'includes/header_cmn';
	    $data['footercontent'] = 'includes/footer_cmn';
		if(!empty($this->session->spare_part_no))
		{
		$data['spare_part_no'] = $this->session->spare_part_no;
		}
		$data['spare_part_no'] = '';
		
		$data['url'] = $this->uri->segment(1);
		$data['url2'] = $this->uri->segment(2);
        $this->load->view('Spare_Parts_List',$data);
        $totalData = $this->spare_list->allspare_parts_count();           
        $totalFiltered = $totalData;		
		$this->session->set_userdata('totalFiltered', $totalData);
		$this->session->set_userdata('totalData', $totalData);
 		
	}
    /*************************************************
             Spart part reference record
    *************************************************/
	/**
       * 
       * filter spare parts based on spare part reference number value 
       * 
       * @param string $search  
       * @param integer $limit  
       * @param integer $start  
       * @param integer $order  
       * @param integer $dir    
       * @return boolean
       */
	public function filtered_spare_parts()
		{
	              
			 $role = $this->session->userdata('role');
			 if($this->input->post('call') == 'temp')
			 {
				 echo '1';
			 }
			 else
			 {				 
			if(!empty($this->input->post('spare_part_no')))
            { 
			$this->session->set_userdata('spare_part_no', $this->input->post('spare_part_no'));
			}
			else
			{
				$this->session->set_userdata('spare_part_no', $this->input->post('spare_part_no'));
			}
			$columns = array( 
                            0 =>'spare_part_number', 
                            1 =>'brand',
                            2=> 'cas_number',
                            3=> 'substance_name',
                            4=> 'article_may_contain',
							5=> 'status',
							6=> 'action',
                        );

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
        
		$limit = $this->security->xss_clean($limit);
		$start = $this->security->xss_clean($start);
		$order = $this->security->xss_clean($order);
		$dir = $this->security->xss_clean($dir);		
        if(empty($this->input->post('spare_part_no')) || strlen($this->input->post('spare_part_no') < 2))
        {    
            
            $spare_parts_list = $this->spare_list->allspare_parts($limit,$start,$order,$dir);
			$this->session->set_userdata('totalFiltered', $this->session->userdata('totalData'));
        }
        else {
				
				$search = trim($this->input->post('spare_part_no')); 
				$spare_parts_list =  $this->spare_list->spare_parts_search($limit,$start,$search,$order,$dir);$totalFiltered = $this->spare_list->spare_parts_search_count($search);
				$this->session->set_userdata('totalFiltered', $totalFiltered);
			
        }
        $data = array();	
        if(!empty($spare_parts_list))
        {   
            foreach ($spare_parts_list as $spare)
            {

			if($spare->status == '1') {$status = '<span class="rec-active"><i class="fa fa-check" title="Active" style="font-size:24px;" aria-hidden="true"></i></span>';} else if($spare->status == '0') {$status = '<span class="rec-error"><i class="fa fa-window-close" style="font-size:24px;" title="Inactive" aria-hidden="true"></i> <span>';} else {$status = '<span class="rec-subs"><i class="fas fa-exchange-alt" title="Substitute" style="font-size:24px;" aria-hidden="true"></i> <span>';}
			
			
                $nestedData['id'] = $spare->id;
                $nestedData['spare_part_number'] = $spare->spare_part_number;
				$nestedData['brand'] = $spare->brand;
                $nestedData['cas_number'] = $spare->cas_number;
				if($this->session->userdata('language')!='')
		{
		$language = $this->session->userdata('language');
		}
		else
		{
		$language = 'en';
		}
				$article_may_txt = $this->spare_list->article_may_contain_txt($language);				
				if($spare->article_may_contain == '1')
				{
				$nestedData['substance_name'] = $article_may_txt[0]->ovl_text.' : '.$spare->substance_name;
				$article_may_contain = '1';
				} 
				else 
				{ 
				$nestedData['substance_name'] = $spare->substance_name;	
                $article_may_contain = '0';				
				}
				$nestedData['status'] = $status;				 
				 if($role == 'ADMIN') 
				{
				$nestedData['article_may_contain'] = $article_may_contain;
				$nestedData['action'] = "<a href='".base_url()."Edit_Spare_Parts/".rtrim(base64_encode($spare->id),'=')."' target='_blank'><i class='fas fa-edit'></i><a>";
                }
                $data[] = $nestedData;
            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($this->session->userdata('totalData')),  
                    "recordsFiltered" => intval($this->session->userdata('totalFiltered')), 
                    "data"            => $data   
                    ); 
					
        echo json_encode($json_data); 		
		}
		}

}
