<?php
/**
 * Req. Id      : REACH_RTM013
 * CAP-NO       : 19689
 * Class        : Language
 * Ddescription : Language Class to manage localiszation
 * @author      : Yogesh Pandey
 * @version     : 1.0
 */
defined('BASEPATH') or exit('No direct script access allowed');

class Language extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this
            ->load
            ->helper('url');
        $this
            ->load
            ->helper("security");
        $this
            ->load
            ->library('session');
        $this
            ->load
            ->model('Get_login_model');
        $this
            ->load
            ->model('Reach_regulation_edit_model', 'edit_regulation');

    }

    public function index()
    {
        $lang = $this
            ->input
            ->post('lang');

        $data = $this
            ->security
            ->xss_clean($lang);

        $result = $this
            ->Get_login_model
            ->get_lang_by($data);
        $result = $result[0];
        if ($result)
        {
            $this
                ->session
                ->set_userdata('language', $result->lang_code);
            $this
                ->session
                ->set_userdata('language_lable', $result->lang_label);

            echo "success";

        }
        else
        {
            echo "error";
        }

    }
}

