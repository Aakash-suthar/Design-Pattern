<?php
/**
 * Req. Id      : REACH_RTM007
 * CAP-NO       : 19689
 * Class        : Add_Spare_Parts
 * Description  : Add_Spare_Parts Class to List all spare parts
 * @author      : Yogesh Pandey
 * @version     : 1.0
 */
defined('BASEPATH') or exit('No direct script access allowed');

class Add_Spare_Parts extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this
            ->load
            ->helper('url');
        $this
            ->load
            ->helper("security");
        $this
            ->load
            ->model('Spare_list_model', 'spare_list');

        $this
            ->load
            ->model('Get_login_model');
        $this
            ->load
            ->library('form_validation');
        $this
            ->load
            ->model('Add_spare_part_model', 'add_part');
        $role = $this->session->userdata('role');
    	if(!isset($role) || $role == ''){
    		redirect('Logout');
    	}
        /*************************************************
        Set default language english if language not set
        *************************************************/
        if ($this
            ->session
            ->userdata('language') != '')
        {
            $language = $this
                ->session
                ->userdata('language');
        }
        else
        {
            $language = 'en';
        }
        if (file_exists("system/language/" . strtolower($language) . "/" . strtolower($language) . "_lang.php"))
        {
            $this
                ->lang
                ->load($language, $language);
        }
        else
        {
              $language = 'en';
            $this
                ->lang
                ->load($language, $language);
        }
        $role = $this
            ->session
            ->userdata('role');
        /*************************************************
        USER validation so that only admin can have access to add spare part feature
        *************************************************/
        if ($role != 'ADMIN')
        {
            redirect('Reach_Regulation');
            exit;
        }
    }

    public function index()
    {
        $data = array();
        $data['maincontent'] = 'includes/header_cmn';
        $data['footercontent'] = 'includes/footer_cmn';
        $data['url'] = $this
            ->uri
            ->segment(1);
        $data['url2'] = $this
            ->uri
            ->segment(2);
        $this
            ->load
            ->view('Add_Spare_Parts', $data);

    }
	/*************************************************
             Add new spart part reference record
    *************************************************/
	/**
                * 
                * Add new spart part reference record
                *
                * @param string $spare_part_number
                * @param string $brand
                * @param string $cas_number
                * @param string $substance_name
                * @param interger $status
                * @param string $comment
                * @return string
                
         */
    public function add_parts()
    {

        
        $this
            ->form_validation
            ->set_rules('spare_part_number', 'Spare Part Number', 'required|max_length[50]');
        $this
            ->form_validation
            ->set_rules('brand', 'Brand', 'max_length[10]');
        $this
            ->form_validation
            ->set_rules('cas_number', 'CAS Number', 'max_length[10]');
        $this
            ->form_validation
            ->set_rules('substance_name', 'Substance Name', 'required');
        $this
            ->form_validation
            ->set_rules('status', 'Status', 'required|max_length[1]');
        /*************************************************
        Server side form validation
        *************************************************/
        if ($this
            ->form_validation
            ->run() == false)
        {
            echo validation_errors();
        }
        else
        {
            $data = array(
                'spare_part_number' => $this
                    ->input
                    ->post('spare_part_number') ,
				'reverse_spare_part_number' => strrev($this
                    ->input
                    ->post('spare_part_number')) ,
                'brand' => $this
                    ->input
                    ->post('brand') ,
                'cas_number' => $this
                    ->input
                    ->post('cas_number') ,
                'substance_name' => $this
                    ->input
                    ->post('substance_name') ,
				'article_may_contain' => $this
                            ->input
                            ->post('article_may_contain') ,	
                'status' => $this
                    ->input
                    ->post('status') ,
                'comment' => $this
                    ->input
                    ->post('comment') ,
                'created_on' => date('Y-m-d H:i:s') ,
				'updated_by' => $this->session->userdata('user_id'),

            );
            /*************************************************
            xss_clean for avoiding cross-side scripting
            *************************************************/
			if($data['article_may_contain'] != '1' )
					{
					$data['article_may_contain'] = '0';	
					}
            $data = $this
                ->security
                ->xss_clean($data);
            $res = $this
                ->add_part
                ->add_spare_part($data);

            if ($res == '1')
            {
                echo "success";
            }
            else if ($res == '2')
            {
                echo "duplicate";
            }
            else
            {
                echo "error";
            }

        }
    }

}

