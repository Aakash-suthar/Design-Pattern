<?php if(!defined('BASEPATH')){ 
		exit('No direct script access allowed');
	  }

/**
 * Class : Access (AccessController)
 * Access class to redirect on unauthorized access
 * @author : Sarita Yadav
 * @version : 1.0
 */
class Sync extends CI_Controller
{
	/**
	 * This is default constructor of the class
	 */
	public function __construct()
	{
		parent::__construct();
		
	}
	
	/**
	 * To load access page and destroy the session.
	 */
	public function index()
	{  

	   $path = $_POST['folder_path'];
    					$doc_arr = array();
    					if (!is_dir($path))
    					{
    					    mkdir($path, 0777, TRUE);
    					}
		$data['maincontent'] = 'includes/header_cmn';
		$data['language'] = $this->session->userdata('language');		
		if (move_uploaded_file($_FILES['file']['tmp_name'], FCPATH.'assets/wallbox_commissioning_report/'.$_POST['file_name'])) {
            echo "successfully uploaded";
        }
		else
		{
			echo "error in upload"; 
		}
	}
	
	
	
}
?>
