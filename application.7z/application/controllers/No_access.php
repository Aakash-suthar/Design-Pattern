<?php
/**
 * Req. Id      : REACH_RTM002
 * CAP-NO       : 19689
 * Class        : No_access
 * Ddescription : No_access Class to display error message when access denied
 * @author      : Yogesh Pandey
 * @version     : 1.0
 */
class No_access extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this
            ->load
            ->library('session');
        $this
            ->load
            ->helper('url');
        $this
            ->load
            ->model('Get_login_model');
        $language = strtolower($this
            ->session
            ->userdata('language'));
        /*************************************************
        Set default language english if language not set
        *************************************************/
        if (file_exists("system/language/" . strtolower($language) . "/" . strtolower($language) . "_lang.php"))
        {
            $this
                ->lang
                ->load($language, $language);
        }
        else
        {
              $language = 'en';
            $this
                ->lang
                ->load($language, $language);

        }
    }

    public function index()
    {
        $data['maincontent'] = 'includes/header_cmn';
        $this
            ->load
            ->view('no_access', $data);
        $this
            ->session
            ->sess_destroy();
        $data['url'] = $this
            ->uri
            ->segment(1);
        $data['url2'] = $this
            ->uri
            ->segment(2);
    }

}
?>
