<?php
$role = $this->session->userdata('role');
 $csrf = array(
	'name' => $this->security->get_csrf_token_name(),
	'hash' => $this->security->get_csrf_hash()
	);
	
	?>
 <!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url(); ?>assets/images/favicon.png">
	<link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url(); ?>assets/css/icons/favicon-16x16.png">
    <title>REACH - DB</title>

   
	<link href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css" rel="stylesheet" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/libs/quill/dist/quill.snow.css">
	<link href="<?php echo base_url(); ?>/assets/css/datatables.net-bs4/css/dataTables.bootstrap4.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>/assets/css/style.min.css" rel="stylesheet">
	<?php	if($this->session->userdata('language') != '' && file_exists(base_url().'/assets/css/language/style_'.$this->session->userdata('language').'.css')) 	{ ?>
	<link href="<?php echo base_url(); ?>/assets/css/language/style_<?php echo $this->session->userdata('language');?>.css" rel="stylesheet" />
		<?php } else { ?> <link href="<?php echo base_url(); ?>/assets/css/style.css" rel="stylesheet" /> <?php } ?>
	<link href="<?php echo base_url(); ?>/assets/css/font-awesome.css" rel="stylesheet" />
	<link href="<?php echo base_url(); ?>/assets/css/toastr.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/flag-icon.min.css">

	<script src="<?php echo base_url(); ?>/assets/js/fontawesome.js" type="text/javascript"></script>

	<script src="<?php echo base_url(); ?>/assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>/assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>/assets/js/popper.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>/assets/js/jquery.dataTables.js" type="text/javascript"></script>
	<script src="<?php echo base_url();?>assets/js/jquery.validate.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url();?>assets/js/additional-methods.js" type="text/javascript"></script>
	<script src="<?php echo base_url();?>assets/js/bs-custom-file-input.js" type="text/javascript"></script>
	<script src="<?php echo base_url();?>assets/js/perfect-scrollbar.jquery.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/toastr.min.js"></script>

<!--Menu sidebar -->
    <script src="<?php echo base_url();?>assets/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="<?php echo base_url();?>assets/js/custom.min.js"></script>
    <!-- This Page JS -->

    <script src="<?php echo base_url();?>assets/js/quill.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/dataTables.bootstrap4.js"></script>
    <script type="text/javascript">
        $(function($) {
            $('.language  a').click(function() {
				
                var element = $(this);
                var lang = element.attr("id");
				
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url();?>Language",
                    data: {lang:lang, "<?php echo $csrf['name'];?>" : "<?php echo $csrf['hash'];?>"},
                    success: function(response) {
                        if (response === 'success') {
                            document.location.reload();
                        } 
						else {
						}
					}
                });
                $(this).parents(".show")
                    .animate({ backgroundColor: "#003" }, "slow")
                    .animate({ opacity: "hide" }, "slow");

                return false;
            });
        });
    </script>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
 <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5">
                    <!-- This is for the sidebar toggle which is visible on mobile only -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
                    <a class="navbar-brand" href="ltr\index.html">
                        <!-- Logo icon -->
                    <?php /*   <b class="logo-icon p-l-10">
                            <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                            <!-- Dark Logo icon -->
                            <img src="<?php echo base_url(); ?>assets/images/logo-icon.png" alt="homepage" class="light-logo" />
                           
                        </b> */?>
                        <!--End Logo icon -->
                         <!-- Logo text -->
                        <div class="logo-text">
                             <!-- dark Logo text -->
                             <img src="<?php echo base_url(); ?>assets/images/6brands_2_blue_print.jpg" alt="homepage" class="light-logo" />
                            
                        </div>
                        <!-- Logo icon -->
                        <!-- <b class="logo-icon"> -->
                            <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                            <!-- Dark Logo icon -->
                            <!-- <img src="<?php echo base_url(); ?>assets/images/logo-text.png" alt="homepage" class="light-logo" /> -->
                            
                        <!-- </b> -->
                        <!--End Logo icon -->
                    </a>
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- Toggle which is visible on mobile only -->
                    <!-- ============================================================== -->
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="ti-more"></i></a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav float-left mr-auto">
                        <li class="nav-item d-none d-md-block"><a class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)" data-sidebartype="mini-sidebar"><i class="mdi mdi-menu font-24"></i></a></li>
                        <!-- ============================================================== -->
                        <!-- create new -->
                        <!-- ============================================================== -->
                       <!-- <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                             <span class="d-none d-md-block">Create New <i class="fa fa-angle-down"></i></span>
                             <span class="d-block d-md-none"><i class="fa fa-plus"></i></span>   
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#">Action</a>
                                <a class="dropdown-item" href="#">Another action</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#">Something else here</a>
                            </div>
                        </li> -->
                        <!-- ============================================================== -->
                        <!-- Search -->
                        <!-- ============================================================== -->
                       <!-- <li class="nav-item search-box"> <a class="nav-link waves-effect waves-dark" href="javascript:void(0)"><i class="ti-search"></i></a>
                            <form class="app-search position-absolute">
                                <input type="text" class="form-control" placeholder="Search &amp; enter"> <a class="srh-btn"><i class="ti-close"></i></a>
                            </form>
                        </li>-->
                    </ul>
                    <!-- ============================================================== -->
                    <!-- Right side toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav float-right">
                        <!-- ============================================================== -->
                        <!-- Comment -->
                        <!-- ============================================================== -->
                       <!--  <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle waves-effect waves-dark" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="mdi mdi-bell font-24"></i>
                            </a>
                             <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#">Action</a>
                                <a class="dropdown-item" href="#">Another action</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#">Something else here</a>
                            </div>
                        </li>-->
                        <!-- ============================================================== -->
                        <!-- End Comment -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- Messages -->
                        <!-- ============================================================== -->
                     <!--   <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle waves-effect waves-dark" href="" id="2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="font-24 mdi mdi-comment-processing"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right mailbox animated bounceInDown" aria-labelledby="2">
                                <ul class="list-style-none">
                                    <li>
                                        <div class="">
                                             <!-- Message -->
                                           <!-- <a href="javascript:void(0)" class="link border-top">
                                                <div class="d-flex no-block align-items-center p-10">
                                                    <span class="btn btn-success btn-circle"><i class="ti-calendar"></i></span>
                                                    <div class="m-l-10">
                                                        <h5 class="m-b-0">Event today</h5> 
                                                        <span class="mail-desc">Just a reminder that event</span> 
                                                    </div>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <!--<a href="javascript:void(0)" class="link border-top">
                                                <div class="d-flex no-block align-items-center p-10">
                                                    <span class="btn btn-info btn-circle"><i class="ti-settings"></i></span>
                                                    <div class="m-l-10">
                                                        <h5 class="m-b-0">Settings</h5> 
                                                        <span class="mail-desc">You can customize this template</span> 
                                                    </div>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <!--<a href="javascript:void(0)" class="link border-top">
                                                <div class="d-flex no-block align-items-center p-10">
                                                    <span class="btn btn-primary btn-circle"><i class="ti-user"></i></span>
                                                    <div class="m-l-10">
                                                        <h5 class="m-b-0">Pavan kumar</h5> 
                                                        <span class="mail-desc">Just see the my admin!</span> 
                                                    </div>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                           <!-- <a href="javascript:void(0)" class="link border-top">
                                                <div class="d-flex no-block align-items-center p-10">
                                                    <span class="btn btn-danger btn-circle"><i class="fa fa-link"></i></span>
                                                    <div class="m-l-10">
                                                        <h5 class="m-b-0">Luanch Admin</h5> 
                                                        <span class="mail-desc">Just see the my new admin!</span> 
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </li> -->
                        <!-- ============================================================== -->
                        <!-- End Messages -->
                        <!-- ============================================================== -->

                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
						<li class="nav-item dropdown">
						<?php if($role == 'ADMIN') {?>
             <div class="dropdown language">
		<button class="btn btn-secondary dropdown-toggle lang-btn" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		<?php  if($this->session->userdata('language') != '')
		{
			$lan_code = $this->session->userdata('language');
			$lang_lable = $this->session->userdata('language_lable');
			$lang_res = $this->Get_login_model->get_lang_by($lan_code);
			
			$lang_lable = ucwords($lang_res[0]->lang_label);
			
		}
		else
		{
			$lan_code = 'en';
			$lang_lable = 'English';
		}
	?>
			<!--<span class="flag-icon flag-icon-<?php //echo $lan_code;?>"></span> --><?php echo $lang_lable;?>
		</button>
		<div class="dropdown-menu dropdown-menu-right text-right language-drp">
		<?php                      
                                    
									
                                    $data['languages'] = array();
                                    $languages = array();
									
                                    $all_language = $this->Get_login_model->all_language();							
                                    foreach ($all_language as $k => $v) {
                                    	 
                                    		//echo '<a class="dropdown-item country-drpdwn" id ="' . $v['lang_code']. '"><span class="flag-icon flag-icon-' . $v['lang_code']. '"> </span> ' . ucwords($v['lang_label']). '</a>';
											if($lan_code == $v['lang_code'])
											{
												echo '<a class="dropdown-item country-drpdwn active" id ="' . $v['lang_code']. '">' . ucwords($v['lang_label']). '</a>';
											}
											else{
											echo '<a class="dropdown-item country-drpdwn" id ="' . $v['lang_code']. '">' . ucwords($v['lang_label']). '</a>';
											}
/*
$file1 = base_url().'/assets/css/style.css'; 
$file2 = 'assets/css/language/style_'.$v["lang_code"].'.css'; 
$file3 = 'assets/css/language/style.css'; 
$file4 = 'assets/css/language/style_en.css'; 
$fileContents1 = file_get_contents($file1);
file_put_contents($file2, $fileContents1);
file_put_contents($file3, $fileContents1);
file_put_contents($file4, $fileContents1);
  
                                    		
    $file1 = 'system/language/en/en_lang.php';                                    		
    $file2 = 'system/language/'.$v["lang_code"].'/'.$v["lang_code"].'_lang.php';                                    		
    $fileContents1 = file_get_contents($file1);                                    		
    file_put_contents($file2, $fileContents1);
 */                                 		
    // put the contents of file1 in the file2
    
 	

                                    	
                                    }
                                    ?>
		    <!--<a class="dropdown-item country-drpdwn" id ="us"><span class="flag-icon flag-icon-us"> </span> English</a>
			<a class="dropdown-item country-drpdwn" id ="fr"><span class="flag-icon flag-icon-fr"> </span> French</a>
			<a class="dropdown-item country-drpdwn" id ="it"><span class="flag-icon flag-icon-it"> </span> Italian</a>
			<a class="dropdown-item country-drpdwn" id ="ru"><span class="flag-icon flag-icon-ru"> </span> Russian</a>-->
		</div>
	</div>
	
	<?php } ?>
                </li> 
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url(); ?>assets/images/users/1.jpg" alt="user" class="rounded-circle" width="31"></a>
                            <div class="dropdown-menu dropdown-menu-right user-dd animated">
                                <a class="dropdown-item" href="javascript:void(0)"><i class="ti-user m-r-5 m-l-5"></i> Welcome, <?php echo $lan_code = $this->session->userdata('user_id');?>!</a>
                               <!-- <a class="dropdown-item" href="javascript:void(0)"><i class="ti-wallet m-r-5 m-l-5"></i> My Balance</a>
                                <a class="dropdown-item" href="javascript:void(0)"><i class="ti-email m-r-5 m-l-5"></i> Inbox</a>-->
                                <!-- <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="javascript:void(0)"><i class="ti-settings m-r-5 m-l-5"></i> Account Setting</a>
                                <div class="dropdown-divider"></div> -->
								<div class="dropdown-divider"></div> 
                                <a class="dropdown-item" href="<?php echo base_url(); ?>Logout"><i class="fa fa-power-off m-r-5 m-l-5"></i> Logout</a>
                                <div class="dropdown-divider"></div>
                                <div class="p-l-30 p-10"><a href="javascript:void(0)" class="btn btn-sm btn-success btn-rounded">OK</a></div>
                            </div>
                        </li>
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                    </ul>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav" class="p-t-30">
					 
					 <?php
$regulation_menu_link = '';
$sparelist_menu_link = '';
$addspare_menu_link = '';
$importspare_menu_link = '';
$requestUri = $url;

if($requestUri == 'Reach_Regulation')
{
	$regulation_menu_link = 'active';
}
else if($requestUri == 'Spare_Parts' || $requestUri == 'Edit_Spare_Parts')
{
	$sparelist_menu_link = 'active';
}
else if($requestUri == 'Add_Spare_Parts')
{
	$addspare_menu_link = 'active';
}
else if($requestUri == 'Import')
{
	$importspare_menu_link = 'active';
}
else
{
	$regulation_menu_link = 'active';
}	
					 ?>
						<li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link <?php echo $regulation_menu_link; ?>" href="<?php echo base_url(); ?>Reach_Regulation" aria-expanded="false"><i class="mdi mdi-file-document"></i><span class="hide-menu">Reach Regulation</span></a></li>
						
						<li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link <?php echo $sparelist_menu_link; ?>" href="<?php echo base_url(); ?>Spare_Parts" aria-expanded="false"><i class="mdi mdi-view-list"></i><span class="hide-menu">Spare Parts List</span></a></li>
						<?php if($role == 'ADMIN') {?>
						<li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link <?php echo $addspare_menu_link; ?>" href="<?php echo base_url(); ?>Add_Spare_Parts" aria-expanded="false"><i class="mdi mdi-receipt"></i><span class="hide-menu">Add Spare Part</span></a></li>
						
						<li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link <?php echo $importspare_menu_link; ?>" href="<?php echo base_url(); ?>Import" aria-expanded="false"><i class="mdi mdi-file-import"></i><span class="hide-menu">Import Spare Parts</span></a></li>
						<?php }?>
                        <!-- <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php //echo base_url(); ?>reach_regulation_edit"aria-expanded="false"><i class="mdi mdi-account-edit"></i><span class="hide-menu">Reach Regulation Edit</span></a></li>-->
						
                       <!-- <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="ltr\charts.html" aria-expanded="false"><i class="mdi mdi-chart-bar"></i><span class="hide-menu">Charts</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="ltr\widgets.html" aria-expanded="false"><i class="mdi mdi-chart-bubble"></i><span class="hide-menu">Widgets</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="ltr\tables.html" aria-expanded="false"><i class="mdi mdi-border-inside"></i><span class="hide-menu">Tables</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="ltr\grid.html" aria-expanded="false"><i class="mdi mdi-blur-linear"></i><span class="hide-menu">Full Width</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="mdi mdi-receipt"></i><span class="hide-menu">Forms </span></a>
                            <ul aria-expanded="false" class="collapse  first-level">
                                <li class="sidebar-item"><a href="ltr\form-basic.html" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Form Basic </span></a></li>
                                <li class="sidebar-item"><a href="ltr\form-wizard.html" class="sidebar-link"><i class="mdi mdi-note-plus"></i><span class="hide-menu"> Form Wizard </span></a></li>
                            </ul>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="ltr\pages-buttons.html" aria-expanded="false"><i class="mdi mdi-relative-scale"></i><span class="hide-menu">Buttons</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="mdi mdi-face"></i><span class="hide-menu">Icons </span></a>
                            <ul aria-expanded="false" class="collapse  first-level">
                                <li class="sidebar-item"><a href="ltr\icon-material.html" class="sidebar-link"><i class="mdi mdi-emoticon"></i><span class="hide-menu"> Material Icons </span></a></li>
                                <li class="sidebar-item"><a href="ltr\icon-fontawesome.html" class="sidebar-link"><i class="mdi mdi-emoticon-cool"></i><span class="hide-menu"> Font Awesome Icons </span></a></li>
                            </ul>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="ltr\pages-elements.html" aria-expanded="false"><i class="mdi mdi-pencil"></i><span class="hide-menu">Elements</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="mdi mdi-move-resize-variant"></i><span class="hide-menu">Addons </span></a>
                            <ul aria-expanded="false" class="collapse  first-level">
                                <li class="sidebar-item"><a href="ltr\index2.html" class="sidebar-link"><i class="mdi mdi-view-dashboard"></i><span class="hide-menu"> Dashboard-2 </span></a></li>
                                <li class="sidebar-item"><a href="ltr\pages-gallery.html" class="sidebar-link"><i class="mdi mdi-multiplication-box"></i><span class="hide-menu"> Gallery </span></a></li>
                                <li class="sidebar-item"><a href="ltr\pages-calendar.html" class="sidebar-link"><i class="mdi mdi-calendar-check"></i><span class="hide-menu"> Calendar </span></a></li>
                                <li class="sidebar-item"><a href="ltr\pages-invoice.html" class="sidebar-link"><i class="mdi mdi-bulletin-board"></i><span class="hide-menu"> Invoice </span></a></li>
                                <li class="sidebar-item"><a href="ltr\pages-chat.html" class="sidebar-link"><i class="mdi mdi-message-outline"></i><span class="hide-menu"> Chat Option </span></a></li>
                            </ul>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="mdi mdi-account-key"></i><span class="hide-menu">Authentication </span></a>
                            <ul aria-expanded="false" class="collapse  first-level">
                                <li class="sidebar-item"><a href="authentication-login.html" class="sidebar-link"><i class="mdi mdi-all-inclusive"></i><span class="hide-menu"> Login </span></a></li>
                                <li class="sidebar-item"><a href="authentication-register.html" class="sidebar-link"><i class="mdi mdi-all-inclusive"></i><span class="hide-menu"> Register </span></a></li>
                            </ul>
                        </li> 
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="mdi mdi-alert"></i><span class="hide-menu">Errors </span></a>
                            <ul aria-expanded="false" class="collapse  first-level">
                                <li class="sidebar-item"><a href="error-403.html" class="sidebar-link"><i class="mdi mdi-alert-octagon"></i><span class="hide-menu"> Error 403 </span></a></li>
                                <li class="sidebar-item"><a href="error-404.html" class="sidebar-link"><i class="mdi mdi-alert-octagon"></i><span class="hide-menu"> Error 404 </span></a></li>
                                <li class="sidebar-item"><a href="error-405.html" class="sidebar-link"><i class="mdi mdi-alert-octagon"></i><span class="hide-menu"> Error 405 </span></a></li>
                                <li class="sidebar-item"><a href="error-500.html" class="sidebar-link"><i class="mdi mdi-alert-octagon"></i><span class="hide-menu"> Error 500 </span></a></li>
                            </ul>
                        </li> -->
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->