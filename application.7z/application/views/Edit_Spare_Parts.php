<?php
   defined('BASEPATH') OR exit('No direct script access allowed');
   if(isset($maincontent)) { $this->load->view($maincontent); }
   //echo $filename;
   	$csrf = array(
	'name' => $this->security->get_csrf_token_name(),
	'hash' => $this->security->get_csrf_hash()
	); 

   ?>
 <div class="page-wrapper">
 <div class="page-breadcrumb">
 <div class="row">
 <div class="col-12 d-flex no-block align-items-center">
                        <h3 class="page-title"><?php echo $this->lang->line('edit_spare_parts_list_head');?></h3>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#"><?php echo $this->lang->line('home');?></a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo $this->lang->line('edit_spare_parts_list');?></li>
                                </ol>
                            </nav>
                        </div>
                    </div> 
</div>
   <form method="post" name="import_form" id="edit_spare_partform"  action="<?php echo base_url();?>Edit_Spare_Parts/edit_spare_part_by_ref"  enctype="application/x-www-form-urlencoded">
   <input type="hidden" name="<?php echo $csrf['name'];?>" value="<?php echo $csrf['hash'];?>" /> 
   <input type="hidden" name="spare_part_id" id="spare_part_id" value="<?php if(isset($spare_part_id)) { echo $spare_part_id; } ?>">
      <div class="myclass-body">
        
        
       <div class="form-row">
    <div class="form-group col-md-6">
      <label for="input_spare_part_number"><?php echo $this->lang->line('spare_part_number');?> <span  style="color:#da542e"> *</span></label>
      <input type="text" class="form-control" id="spare_part_number" name="spare_part_number" value="<?php if(isset($spare_part_number)) { echo $spare_part_number; } ?>" placeholder="Spare Part Number">
    </div>
    <div class="form-group col-md-6">
      <label for="input_brand"><?php echo $this->lang->line('brand');?></label>
      <input type="text" class="form-control" id="brand"  name="brand" value="<?php if(isset($brand)) { echo $brand; } ?>"  placeholder="Brand">
    </div>
  </div>
  <div class="form-row">
<div class="form-group col-md-6">
      <label for="input_cas_number"><?php echo $this->lang->line('cas_number');?></label>
      <input type="text" class="form-control" id="cas_number"  name="cas_number"  value="<?php if(isset($cas_number)) { echo $cas_number; } ?>" placeholder="CAS Number">
    </div>
<div class="form-group col-md-6">
      <label for="inputsubstance_name"><?php echo $this->lang->line('substance_name');?><span  style="color:#da542e"> *</span></label>
      <input type="text" class="form-control" id="substance_name"   name="substance_name"  value="<?php if(isset($substance_name)) { echo $substance_name; } ?>"placeholder="Substance Name">
    </div>
  </div>
  
  <div class="form-row">
   
<div class="form-group col-md-6">
    <label for="status"><?php echo $this->lang->line('status');?></label>
    <select class="form-control" id="status" name="status">
	  <option value="1" <?php if(isset($status) && $status == 1 ) { echo 'selected'; } ?>>Active</option>
      <option value="0" <?php if(isset($status) && $status == 0 ) { echo 'selected'; } ?>>Inactive</option>      
      <option value="2" <?php if(isset($status) && $status == 2 ) { echo 'selected'; } ?>>Substitute</option>
	  <option value="3" <?php if(isset($status) && $status == 3 ) { echo 'selected'; } ?>>Delete</option>
      
    </select>
    </div>
	<div class="form-group col-md-6">
      <label for="input_article_may_contain"><?php echo $this->lang->line('article_may_contain');?></label>      
	   <input type="checkbox" type="text" class="form-control" id="article_may_contain"   name="article_may_contain" placeholder="<?php echo $this->lang->line('article_may_contain');?>" style="width: auto;margin: 10px;" <?php if($article_may_contain == 1) {echo "checked"; } ?> value="1">

    </div>
    </div>
	
<div class="form-row">
	<div class="form-group col-md-12">
      <label for="input_article_may_contain"><?php echo $this->lang->line('comment');?></label>
      <textarea type="text" class="form-control" id="comment"   name="comment" placeholder="Comment" style="    height: 60px;"><?php if(isset($comment)) { echo $comment; } ?></textarea>

    </div>
    </div>	
  
 <div class="form-row">
 <div class="form-group col-md-12">
  <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('update');?></button>
  </div>
  </div>  
    <div class="form-row">
  <div class="col-md-12 col-sm-12 col-xs-12 ">
               <div class="alert alert-success alert-dismissible fade show" role="alert"  id="success-msg">
                  <strong title="Success"><?php echo $this->lang->line('data_updated_successfully');?></strong> 
                  <button type="button" class="close" data-hide="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
          
                <div class="alert alert-success alert-dismissible fade show" role="alert"  id="deleted-msg">
                  <strong title="Success"><?php echo $this->lang->line('data_deleted_successfully');?></strong> 
                  <button type="button" class="close" data-hide="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
			   
               <div class="alert alert-danger alert-dismissible fade show" role="alert"  id="fail-msg">
                  <strong id="fail_msg_text" title="<?php echo $this->lang->line('something_went_wrong');?>">
                  <?php
                     echo $this->lang->line('something_went_wrong');
                     ?></strong> 
                  <button type="button" class="close" data-hide="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
            
			
               <div class="alert alert-danger alert-dismissible fade show" role="alert"  id="duplicate-msg">
                  <strong id="fail_msg_text" title="<?php echo $this->lang->line('something_went_wrong');?>">
                  <?php
                     echo $this->lang->line('duplicate_record');
                     ?></strong> 
                  <button type="button" class="close" data-hide="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
            </div>
			</div>
			
			
      </div>
   </form>
</div>
</div>

<!-- ============================================================== -->
<!-- Main wrapper - END DIV & BODY END Tags BELOW -->
<!-- ============================================================== -->
</div>
</body>
</html>
<!-- ============================================================== -->
<!-- ============================================================== -->

<script>

$(function(){ 
 	$("[data-hide]").on("click", function(){ 
 	$(this).closest("." + $(this).attr("data-hide")).hide(); 
 	}); 
 	 
 	 
 	});
bsCustomFileInput.init();

$(document).ready(function() {
$('#sidebarCollapse').on('click', function() {
            $('#sidebar').toggleClass('active');
        });
    $("form[id='edit_spare_partform']").validate({
        // Specify validation rules
        rules: {
         spare_part_number: 
			{ required: true,
              maxlength: 50,},
			 brand: 
			{ maxlength: 10, },
			 cas_number: 
			{ maxlength: 10, },
			 substance_name: 
			{ required: true, },
			 
        },
        // Specify validation error messages
        messages: {
            spare_part_number: 
			{ required: "<?php echo $this->lang->line('enter_spare_part_Number');?>", },
			 brand: 
			{ required: "<?php echo $this->lang->line('enter_brand');?>", },
			 cas_number: 
			{ required: "<?php echo $this->lang->line('enter_cs_number');?>", },
			 substance_name: 
			{ required: "<?php echo $this->lang->line('enter_substance_name');?>", },
			

        },
        
        // Make sure the form is submitted to the destination defined
        // in the "action" attribute of the form when valid
        submitHandler: function(form) {
            var formdata = new FormData($("#edit_spare_partform")[0]);
            //console.log(formdata);
            $.ajax({
                url: $('#edit_spare_partform').attr('action'),
                type: 'POST',
                data: formdata,
                processData: false,
                contentType: false,
                datatype: 'json',
                success: function(response) {
					
                       if (response === 'success') {


					$("#success-msg").fadeTo(2000, 500).slideUp(500, function(){
					$("#success-msg").slideUp(500); 
					});
                        
                        setTimeout(function() {
						window.location ='<?php echo base_url(); ?>Spare_Parts';
                        }, 1000);
                        
                     }
                    else if (response === 'duplicate') {
						
					$("#duplicate-msg").fadeTo(2000, 500).slideUp(500, function(){
					$("#duplicate-msg").slideUp(500); 
					});
					}
                    else if (response === 'deleted') {
						
					$("#deleted-msg").fadeTo(2000, 500).slideUp(500, function(){
					$("#deleted-msg").slideUp(500); 
					});                    
                      setTimeout(function() {
                            //window.location.href = "<?php echo base_url(); ?>Spare_Parts";
					window.location ='<?php echo base_url(); ?>Spare_Parts';
                        }, 2000);  
                    } else {
                        
					$("#fail-msg").fadeTo(2000, 500).slideUp(500, function(){
					$("#fail-msg").slideUp(500); 
					});

                        
                    }
               
				}
            });
        }
    });
}); 
</script>
<?php //require_once('main.php')?>