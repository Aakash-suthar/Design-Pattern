<?php
   defined('BASEPATH') OR exit('No direct script access allowed');
   if(isset($maincontent)) { $this->load->view($maincontent); }
   //echo $filename;
   	$csrf = array(
   'name' => $this->security->get_csrf_token_name(),
   'hash' => $this->security->get_csrf_hash()
   ); 
   
   ?>
<div class="page-wrapper">
   <div class="page-breadcrumb">
      <div class="row">
         <div class="col-12 d-flex no-block align-items-center">
            <h4 class="page-title"><?php echo $this->lang->line('import_data_head');?></h4>
            <div class="ml-auto text-right">
               <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                     <li class="breadcrumb-item"><a href="#"><?php echo $this->lang->line('home');?></a></li>
                     <li class="breadcrumb-item active" aria-current="page"><?php echo $this->lang->line('import_data_bread');?></li>
                  </ol>
               </nav>
            </div>
         </div>
      </div>
      <form method="post" name="import_form" id="import_form"  action="<?php echo base_url();?>import/upload"  enctype="application/x-www-form-urlencoded">
         <input type="hidden" name="<?php echo $csrf['name'];?>" value="<?php echo $csrf['hash'];?>" /> 
         <div class="myclass-body">
            <div class="row">
               <div class="col-md-6 col-sm-12 col-xs-12 upload-active">
                  <div class="form-group">
                     <div class="input-group ">
                        <div class="custom-file">
                           <input id="inputGroupFile01" name="inputGroupFile01" type="file" class="custom-file-input">
                           <label class="custom-file-label"  for="inputGroupFile01"><?php echo $this->lang->line('choose_file');?></label>
                        </div>
                     </div>
                  </div>
               </div>
			   <div class="col-md-2 col-sm-2 col-xs-2 preload">
                  <div class="form-group">
                    <div> <img src="<?php echo base_url(); ?>/assets/images/loader-1.gif" style="width: 40px;"></div>
                  </div>
				  
				   
               </div>
               <div class="col-md-2 col-sm-2 col-xs-2 upload-active-import">
                  <div class="form-group">
                     <div class="update ml-auto mr-auto ">
                        <button type="submit" class="btn btn-round" id="import_submit" title="import"><i class="fa fa-upload"> </i> <?php echo $this->lang->line('import');?> </button>
                     </div>
                  </div>
               </div>
               
                <div class="col-md-12 col-sm-12 col-xs-12 ">
            <div class="error-text"   ></div>
         </div>
            </div>
            <table class="table table-bordered">
               <tbody>
                  <tr>
                     <th scope="row">Download sample .xlsx file for OV data format : <a href="<?php echo base_url();?>upload/OVL-Format.xlsx" class="sample-download" download>OV - Format.xlsx</a></th>
                  </tr>
                  <tr>
                     <th scope="row">Download sample .xlsx file of Reach Format  : <a href="<?php echo base_url();?>upload/PCD-Format.xlsx" class="sample-download" download>PCD - Format.xlsx</a></th>
                  </tr>
               </tbody>
            </table>
            
            
			
		   <div class="form-row">
  <div class="col-md-12 col-sm-12 col-xs-12 ">
               <div class="alert alert-success alert-dismissible fade show" role="alert"  id="success-msg">
                  <strong title="Success"><?php echo $this->lang->line('import_successful');?></strong> 
                  <button type="button" class="close" data-hide="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
          
            
               <div class="alert alert-danger alert-dismissible fade show" role="alert"  id="fail-msg">
                  <strong id="fail_msg_text" title="<?php echo $this->lang->line('Error_in_file');?>">
                  <?php
                     echo $this->lang->line('Error_in_file');
                     ?></strong> 
                  <button type="button" class="close" data-hide="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
			   
			         <div class="alert alert-danger alert-dismissible fade show" role="alert"  id="invalid-msg">
                  <strong id="fail_msg_text" title="<?php echo $this->lang->line('Invalid_extension');?>">
                  <?php
                     echo $this->lang->line('Invalid_file_extension');
                     ?></strong> 
                  <button type="button" class="close" data-hide="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
            
			
               <div class="alert alert-danger alert-dismissible fade show" role="alert"  id="duplicate-msg">
                  <strong id="fail_msg_text" title="<?php echo $this->lang->line('something_went_wrong');?>">
                  <?php
                     echo $this->lang->line('duplicate_record');
                     ?></strong> 
                  <button type="button" class="close" data-hide="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
            </div>
			</div>	
			
         </div>
      </form>
   </div>
</div>
<!-- ============================================================== -->
<!-- Main wrapper - END DIV & BODY END Tags BELOW -->
<!-- ============================================================== -->
</div>
</body>
</html>
<!-- ============================================================== -->
<!-- ============================================================== -->
<script>
$(function(){ 
 	$("[data-hide]").on("click", function(){ 
 	$(this).closest("." + $(this).attr("data-hide")).hide(); 
 	}); 
 	 
 	 
 	});

   bsCustomFileInput.init();
   
   $(document).ready(function() {
   $('#sidebarCollapse').on('click', function() {
               $('#sidebar').toggleClass('active');
           });
       $("form[id='import_form']").validate({
           // Specify validation rules
           rules: {
               inputGroupFile01: {
   
                   required: true,
                   extension: "xlsx|xls",
                   maxsize: 20000000,
   
               },
           },
           // Specify validation error messages
           messages: {
               inputGroupFile01: {
   
                   required: "<?php echo $this->lang->line('filetoupload');?> ",
                   maxsize: "<?php echo $this->lang->line('maxallowedimport');?> "
               },
   
           },
           errorElement: 'div',
           errorLabelContainer: '.error-text',
           // Make sure the form is submitted to the destination defined
           // in the "action" attribute of the form when valid
           submitHandler: function(form) {
               var formdata = new FormData($("#import_form")[0]);
			   $('.preload').css('display','block');
			   $('.upload-active-import').css('display','none');
			   
               //console.log(formdata);
               $.ajax({
                   url: $('#import_form').attr('action'),
                   type: 'POST',
                   data: formdata,
                   processData: false,
                   contentType: false,
                   datatype: 'json',
                   success: function(response) {
                       if (response === 'success') {
   						 $('.preload').css('display','none');
						 $('.upload-active-import').css('display','block');
                    $("#success-msg").fadeTo(2000, 500).slideUp(500, function(){
					$("#success-msg").slideUp(500); 
					});
                   //toastr.success('Record Added Successfully!', 'Attention!');
   				setTimeout(function() {
   			document.location.reload()
   			}, 5000);
   					}
					else if (response === 'invalid_extension') {
   						$('.preload').css('display','none');
						$('.upload-active-import').css('display','block');
                    $("#invalid-msg").fadeTo(2000, 500).slideUp(500, function(){
					$("#invalid-msg").slideUp(500); 
					});
                   //toastr.success('Record Added Successfully!', 'Attention!');
   				setTimeout(function() {
   			document.location.reload()
   			}, 5000);
   					}
   						else
   						{
							$('.preload').css('display','none');
							$('.upload-active-import').css('display','block');
   					$("#fail-msg").fadeTo(2000, 500).slideUp(500, function(){
					$("#fail-msg").slideUp(500); 
					});
   							 window.open("<?php echo base_url();?>"+response)
   							 
   							//toastr.error('Something Went Wrong!', 'Inconceivable!');
   						}
                           
                       },
         error: function() {
           toastr.error('Something Went Wrong!', 'Inconceivable!');
         }					
                   } );
           }
       });
   }); 
</script>
<?php //require_once('main.php')?>