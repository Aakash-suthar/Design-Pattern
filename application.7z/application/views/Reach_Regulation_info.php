<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(isset($maincontent)) { $this->load->view($maincontent); }
$csrf = array(
	'name' => $this->security->get_csrf_token_name(),
	'hash' => $this->security->get_csrf_hash()
	); 

?>


 

 <div class="page-wrapper">

                 
   

<div class="page-breadcrumb">
<div class="row">
 <div class="col-12 d-flex no-block align-items-center">
                        <h3 class="page-title">REACH REGULATON</h3>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Regulation</li>
                                </ol>
                            </nav>
                        </div>
                    </div> 
</div>					
      <div class="myclass-body">
<?php if($this->session->userdata('role') != '' &&  $this->session->userdata('role')== 'ADMIN') {?>
	    <form method="post" name="import_form" id="edit_reach_regulation"  action="<?php echo base_url();?>Reach_Regulation/save"  enctype="application/x-www-form-urlencoded">
		<input type="hidden" name="<?php echo $csrf['name'];?>" value="<?php echo $csrf['hash'];?>" /> 
		<input type="hidden" name="lang_id" value="<?php echo $lang_id;?>" /> 
        <input name="about" type="hidden" id="about">
	 <div id="editor" style="height:350px">
                                    
                                </div>
								<br><label id="reach-regulation-error" class="error" for="editor"><?php echo $this->lang->line('reach_regulation_error');?></label>
								     <div class="form-row">
  <div class="form-group col-md-12 col-sm-12 col-xs-12 ">
								<button type="button" class="btn btn-primary" id="submit_regulation"><?php echo $this->lang->line('save');?></button>
  
  </div>
  </div>
     <div class="form-row">
  <div class="form-groupcol-md-12 col-sm-12 col-xs-12 ">
               <div class="alert alert-success alert-dismissible fade show" role="alert"  id="success-msg">
                  <strong title="Success"><?php echo $this->lang->line('data_updated_successfully');?></strong> 
                  <button type="button" class="close" data-hide="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
          
            
               <div class="alert alert-danger alert-dismissible fade show" role="alert"  id="fail-msg">
                  <strong id="fail_msg_text" title="<?php echo $this->lang->line('something_went_wrong');?>">
                  <?php
                     echo $this->lang->line('something_went_wrong');
                     ?></strong> 
                  <button type="button" class="close" data-hide="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
            
			
               <div class="alert alert-danger alert-dismissible fade show" role="alert"  id="duplicate-msg">
                  <strong id="fail_msg_text" title="<?php echo $this->lang->line('something_went_wrong');?>">
                  <?php
                     echo $this->lang->line('duplicate_record');
                     ?></strong> 
                  <button type="button" class="close" data-hide="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
            </div>
			</div>
  
								</form>
	
<?php } else { ?>  
<div id="editor1" >
                                  
</div>  
<?php } ?>  
</div>


</div>
</div>


<!-- ============================================================== -->
<!-- Main wrapper - END DIV & BODY END Tags BELOW -->
<!-- ============================================================== -->
</div>
</body>
</html>
<!-- ============================================================== -->
<!-- ============================================================== -->
   
<script>

$(function(){ 
 	$("[data-hide]").on("click", function(){ 
 	$(this).closest("." + $(this).attr("data-hide")).hide(); 
 	}); 
 	 
 	 
 	});


<?php if($this->session->userdata('role') != '' && $this->session->userdata('role') == 'ADMIN') {?>
var toolbarOptions = [
  ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
  ['blockquote', 'code-block'],

  [{ 'header': 1 }, { 'header': 2 }],               // custom button values
  [{ 'list': 'ordered'}, { 'list': 'bullet' }],
  [{ 'script': 'sub'}, { 'script': 'super' }],      // superscript/subscript
  [{ 'indent': '-1'}, { 'indent': '+1' }],          // outdent/indent
  [{ 'direction': 'rtl' }],                         // text direction

  [{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
  [{ 'header': [1, 2, 3, 4, 5, 6, false] }],

  [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
  [{ 'font': [] }],
  [{ 'align': [] }],

  ['clean']                                         // remove formatting button
];

var quill = new Quill('#editor', {
  modules: {
    toolbar: toolbarOptions
  },
  theme: 'snow'
});

quill.setContents(<?php echo $reach_regulation_text;?>); 

$(document).ready(function() {
$('#sidebarCollapse').on('click', function() {
            $('#sidebar').toggleClass('active');
        });
var about = document.querySelector('input[name=about]');
about.value = JSON.stringify(quill.getContents());

function isQuillEmpty(quill) {
    if (JSON.stringify(quill.getContents()) == "\{\"ops\":[\{\"insert\":\"\\n\"\}]\}") {
        return true;
    } else {
        return false;
    }
}

$( "#submit_regulation" ).click(function() {
if(isQuillEmpty(quill))
{
	$("#reach-regulation-error").css('display','block');
	return false;
}
else
{
$("#reach-regulation-error").css('display','none');	
$.ajax({
  type: "POST",
  url: $('#edit_reach_regulation').attr('action'),
  data: {"editor_data" : JSON.stringify(quill.getContents()), "<?php echo $csrf['name'];?>" : "<?php echo $csrf['hash'];?>", "lang_id" :"<?php echo $lang_id;?>" },
  success: function (response) {
           if(response == 'success')
		   {
			  $("#success-msg").fadeTo(2000, 500).slideUp(500, function(){
					$("#success-msg").slideUp(500); 
					});
			setTimeout(function() {
			document.location.reload()
			}, 5000);
		   }
		   else
		   {
			   $("#fail-msg").fadeTo(2000, 500).slideUp(500, function(){
					$("#fail-msg").slideUp(500); 
					});
		   }
        },
        error: function () {
            alert("error");
        }
});
}
});
});
<?php } else {?>
$(document).ready(function() {
var toolbarOptions1 = '';

var quill1 = new Quill('#editor1', {
  modules: {
    toolbar: toolbarOptions1
  },
  theme: 'snow'
});
quill1.setContents(<?php echo $reach_regulation_text;?>); 
 
}); 
<?php } ?>
</script>

<?php //require_once('main.php')?>