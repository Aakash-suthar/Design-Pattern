<!DOCTYPE html>

<html >
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
ERROR 403!
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  
	<link href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css" rel="stylesheet" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/libs/quill/dist/quill.snow.css">
	<link href="<?php echo base_url(); ?>/assets/css/datatables.net-bs4/css/dataTables.bootstrap4.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>/assets/css/style.min.css" rel="stylesheet">

	<link href="<?php echo base_url(); ?>/assets/css/language/style.css" rel="stylesheet" />
	
	<link href="<?php echo base_url(); ?>/assets/css/font-awesome.css" rel="stylesheet" />
	<link href="<?php echo base_url(); ?>/assets/css/toastr.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/flag-icon.min.css">
	   
</head>
<body>
	<div class="content">
	
 <div class="error-box">
            <div class="error-body text-center">
                <h1 class="error-title text-danger">403</h1>
                <h3 class="text-uppercase error-subtitle">SESSION EXPIRED!</h3>                
                <a href="<?php echo base_url(); ?>" class="btn btn-danger btn-rounded waves-effect waves-light m-b-40">Back to home</a> </div>
        </div>
</div>
</body>
 
</html>
<?php
exit;
?>
