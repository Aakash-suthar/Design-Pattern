<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(isset($maincontent)) { $this->load->view($maincontent); }
	$csrf = array(
	'name' => $this->security->get_csrf_token_name(),
	'hash' => $this->security->get_csrf_hash()
	); 
$role = $this->session->userdata('role');
?>



 <div class="page-wrapper">
 <div class="page-breadcrumb">
<div class="row">
 <div class="col-12 d-flex no-block align-items-center">
                        <h3 class="page-title"><?php echo $this->lang->line('spare_parts_list_head');?></h3>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#"><?php echo $this->lang->line('home');?></a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo $this->lang->line('spare_parts_list');?></li>
                                </ol>
                            </nav>
                        </div>
                    </div> 
</div>
   <form method="post" name="search_form" id="search_form" action="<?php echo base_url(); ?>Spare_Parts/filtered_spare_parts" novalidate="novalidate">
      <input type="hidden" name="<?php echo $csrf['name'];?>" value="<?php echo $csrf['hash'];?>" /> 
	  <div class="myclass-body">

         <div class="row">
            <div class="col-md-6 col-sm-12 col-xs-12">
               <div class="form-group">
                  <label title="WallBox Serial Number"><?php echo $this->lang->line('search_spare_part_by_reference');?></label><span class="req-field">*</span>
                  <input type="text" minlength="8" class="form-control" id="spare_part_number" name="spare_part_number" placeholder="<?php echo $this->lang->line('enter_spare_part_number');?>" value="<?php if( isset($spare_part_no)) { echo $spare_part_no; }?>">
                  <span class="error" id="serial_wb_no_err"></span>
               </div>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2">
               <div class="form-group">
                  <div class="update ml-auto mr-auto">
                     <button type="submit" class="btn btn-round" id="search_submit" title="Search"><i class="fas fa-search"> </i> <?php echo $this->lang->line('search');?> </button>
                  </div>
               </div>
            </div>
			
			<div class="col-md-2 col-sm-2 col-xs-2">
               <div class="form-group">
                  <div class="update ml-auto mr-auto export-inactive">
				  <button type="button" class="btn btn-round grey"  title="Search"><i class="mdi mdi-export" aria-hidden="true"></i> &nbsp;<?php echo $this->lang->line('export_data');?> </button>
                    
                  </div>
				  <div class="update ml-auto mr-auto export-active">
                   <button type="button" class="btn btn-round grey"  title="Search"><i class="mdi mdi-export" aria-hidden="true"></i> &nbsp;<?php echo $this->lang->line('export_data');?> </button>
                  </div>
               </div>
            </div>
			

         </div>
      </div>
	  
	     <div class="form-row">
  <div class="col-md-12 col-sm-12 col-xs-12 ">
               <div class="alert alert-success alert-dismissible fade show" role="alert"  id="success-msg">
                  <strong title="Success"><?php echo $this->lang->line('import_successful');?></strong> 
                  <button type="button" class="close" data-hide="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
          
            
               <div class="alert alert-danger alert-dismissible fade show" role="alert"  id="fail-msg">
                  <strong id="fail_msg_text" title="<?php echo $this->lang->line('something_went_wrong');?>">
                  <?php
                     echo $this->lang->line('something_went_wrong');
                     ?></strong> 
                  <button type="button" class="close" data-hide="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
            
			
               <div class="alert alert-danger alert-dismissible fade show" role="alert"  id="duplicate-msg">
                  <strong id="fail_msg_text" title="<?php echo $this->lang->line('something_went_wrong');?>">
                  <?php
                     echo $this->lang->line('duplicate_record');
                     ?></strong> 
                  <button type="button" class="close" data-hide="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
            </div>
			</div>
   </form>
   <div class="myclass-body">
   <table id="spare_parts_list_info" class="display table table-striped table-bordered" style="border-spacing:0px !important;">
      <thead>
		<tr>

		<th><?php echo $this->lang->line('spare_part_no');?></th>
		<th><?php echo $this->lang->line('brand');?></th>
		<th><?php echo $this->lang->line('cas_no');?></th>
		<th><?php echo $this->lang->line('substance');?></th> 
		<?php if($role == 'ADMIN') { ?>			
		<th style="font-size:11px;"><?php echo $this->lang->line('article_may_contain');?></th>  
				
		<th><?php echo $this->lang->line('status');?></th>
		
		<th><?php echo $this->lang->line('action');?></th>
		<?php } ?>
		
		<?php if($role == 'REPAIRER') { ?>		
					
		<th><?php echo $this->lang->line('status');?></th>
		
		<?php } ?>
		</tr>
      </thead>
      
   </table>
   </div>
</div>
</div>
</div>


<!--<div class="row">
	<div class="col-md-12">
               <table class="table table-bordered" id="posts">
                    <thead>
                           <th>Id</th>
                           <th>Title</th>
                           <th>Body</th>
                           <th>Created At</th>
                    </thead>				
               </table>
        </div>
</div> -->
<!-- Header END BELOW Tags-->
</div>
</body>
</html>
<!--  -->
<script>
$(function(){ 
 	$("[data-hide]").on("click", function(){ 
 	$(this).closest("." + $(this).attr("data-hide")).hide(); 
 	}); 
 	 
 	 
 	});
    $(document).ready(function() {
	$( ".export-active" ).click(function() {
			window.open("<?php echo base_url();?>/Export");
	 });	
		$('#sidebarCollapse').on('click', function() {
            $('#sidebar').toggleClass('active');
        });
    var spare_part_no_field = $('#spare_part_number').val();
	if(spare_part_no_field.length > 4 )
	{
		$('.export-inactive').css('display', 'none');
		$('.export-active').css('display', 'block');
	}			
	
        
        $('#example').DataTable().destroy();
        $('#example').empty();
		
$('#spare_parts_list_info').DataTable({
            "processing": true,
            "serverSide": true,
			"bFilter": false,
            "ajax":{
		    "url": "<?php echo base_url().'Spare_Parts/filtered_spare_parts'?>",
		     "dataType": "json",
		     "type": "POST",
		     //"data":{  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>' }
			 "data":{  'spare_part_no':$('#spare_part_number').val(), "<?php echo $csrf['name'];?>" : "<?php echo $csrf['hash'];?>"  }
		                   },
	    "columns": [

		          { "data": "spare_part_number" },
		          { "data": "brand" },
		          { "data": "cas_number" },
		          { "data": "substance_name" },
				  <?php if($role == 'ADMIN') { ?>
				  { "data": "article_may_contain" },				  
				  { "data": "status" },				 
				  { "data": "action" },
				  <?php } ?>
				  <?php if($role == 'REPAIRER') { ?>					  
				  { "data": "status" },				
				  <?php } ?>
		       ],
		       "columnDefs": [
		           { "width": "100px", "targets": 0 },
				    
		           { "width": "30px", "targets": 1 },
		           { "width": "70px", "targets": 2 },
		           { "width": "200px", "targets": 3 },
				  <?php if($role == 'ADMIN') { ?> 
		           { "width": "56px", "targets": 4 },
				   
				   { "width": "10px", "targets": 5 },
				    
		           { "width": "10px", "targets": 6 },
				   { "orderable": false, "targets": [1,2,3,4,5,6] }
				     <?php } ?>
					 <?php if($role == 'REPAIRER') { ?>	
		          
				   { "width": "10px", "targets": 4 },
				     { "orderable": false, "targets": [1,2,3,4] }
				     <?php } ?>
					 
		         ],
				 order: [[ 0, "asc" ]], //column indexes is zero based
			   "autoWidth": false,
"language": {
                "lengthMenu": "<?php echo $this->lang->line('records_per_page');?>",
                "search": "<?php echo $this->lang->line('search');?>",
                "zeroRecords": "<?php echo $this->lang->line('no_result_found');?>",
                "info": "<?php echo $this->lang->line('showing_records');?>",
                "infoEmpty": "<?php echo $this->lang->line('no_result_found');?>",
                "infoFiltered": "(filtered from _MAX_ total records)",
    			"oPaginate":{
    				"sNext": "<?php echo $this->lang->line('next');?>",
    				"sLast": "<?php echo $this->lang->line('last');?>",
    				"sFirst": "<?php echo $this->lang->line('first');?>",
    				"sPrevious": "<?php echo $this->lang->line('previous');?>"
    			},
    			// "processing": "<img src='<?php echo base_url();?>assets/images/DIST/loading_color.gif' />",
            }			   

});

       $("form[id='search_form']").validate({
            // Specify validation rules
            rules: {
                spare_part_number: {
                   required:true,
                    minlength: 5,
                },


            },
            // Specify validation error messages
            messages: {
                spare_part_number: {
                    required: "<?php echo $this->lang->line('enter_spare_part_reference');?>",
                    minlength: "<?php echo $this->lang->line('first_five_character');?>"
                },

            },

            // Make sure the form is submitted to the destination defined
            // in the "action" attribute of the form when valid
            submitHandler: function(form) {
                var data = $('#search_form').serialize();
                //console.log(formdata);
                $.ajax({
                    url: $('#search_form').attr('action'),
                    type: 'POST',
                    data: {"call":"temp", "<?php echo $csrf['name'];?>" : "<?php echo $csrf['hash'];?>"},
                    datatype: 'json',
                    success: function(response) {
                        if (response === 'empty') {
                            $('.edit_form_wallbox').css('display', 'none');
                            $('#fail-search-msg').css('display', 'block');
                            $('.display_logs').css('display', 'none');
                        } 
						else {
							var number = $('#spare_part_number').val();
							
							if(number.length > 4)
							{
		$('.export-inactive').css('display', 'none');
		$('.export-active').css('display', 'block');
							}
else
{
	$('.export-inactive').css('display', 'block');
		$('.export-active').css('display', 'none');
}	
		$('#spare_parts_list_info').DataTable().destroy();
        $('#spare_parts_list_info').empty();

		
		$('#spare_parts_list_info').DataTable({
            "processing": true,
            "serverSide": true,
			"bFilter": false,
            "ajax":{
		     "url": "<?php echo base_url().'Spare_Parts/filtered_spare_parts'?>",
		     "dataType": "json",
		     "type": "POST",
		     //"data":{  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>' }
			 "data":{   "spare_part_no": $('#spare_part_number').val(), "<?php echo $csrf['name'];?>" : "<?php echo $csrf['hash'];?>" }
		                   },
			"autoWidth": true,
	    "columns": [
                  
		          { "title": "<?php echo $this->lang->line('spare_part_no');?>","data": "spare_part_number" },
		          { "title": "<?php echo $this->lang->line('brand');?>","data": "brand" },
		          { "title": "<?php echo $this->lang->line('cas_number');?>","data": "cas_number" },
		          { "title": "<?php echo $this->lang->line('substance_name');?>","data": "substance_name" },
				   <?php if($role == 'ADMIN') { ?>
				  { "title": "<?php echo $this->lang->line('article');?>","data": "article_may_contain" },
				
				  { "title": "<?php echo $this->lang->line('status');?>","data": "status" },
				    
				  { "title": "<?php echo $this->lang->line('action');?>","data": "action" },
					<?php } ?>
					<?php if($role == 'REPAIRER') { ?>	
				 
				 
				  { "title": "<?php echo $this->lang->line('status');?>","data": "status" },
				   
					<?php } ?>
		       ],
		       "columnDefs": [
		           { "width": "100px", "targets": 0 },
		           { "width": "40px", "targets": 1 },
		           { "width": "100px", "targets": 2 },
		           { "width": "70px", "targets": 3 },
				   <?php if($role == 'ADMIN') { ?>
		           { "width": "40px", "targets": 4 },
				  
				   { "width": "10px", "targets": 5 },
		           
		           { "width": "10px", "targets": 6 },
				   { "orderable": false, "targets": [1,2,3,4,5,6] }
				     <?php } ?>
					 <?php if($role == 'REPAIRER') { ?>	
		           
				  
				   { "width": "10px", "targets": 4 },
				   { "orderable": false, "targets": [1,2,3,4] }
		          
		          
				     <?php } ?>
		         ],
				 order: [[ 0, "asc" ]], //column indexes is zero based
	 

});

        				}
                    }
                });
            }
        });
    }); 
	</script>


