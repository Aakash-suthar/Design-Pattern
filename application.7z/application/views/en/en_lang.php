<?php
$lang['session_expired'] = 'SESSION EXPIRED';
$lang['add_spare_part_head'] = 'ADD SPARE PART'; 
$lang['Error_in_file'] = 'Error in file you are trying to import'; 
$lang['Invalid_extension'] = 'Invalid File Extension'; 
$lang['Invalid_file_extension'] = 'Invalid File Extension'; 
$lang['home'] = 'Home'; 
$lang['add_spare_part'] = 'Add Spare Part'; 
$lang['active'] = 'Active'; 
$lang['inactive'] = 'Inactive'; 
$lang['substituted'] = 'Substituted';

$lang['spare_parts_list'] = 'Spare Parts List';
$lang['edit_spare_parts_list'] = 'Edit Spare Parts List';
$lang['edit_spare_parts_list_head'] = 'EDIT SPARE PART LIST';

$lang['spare_parts_list_head'] = 'SPARE PART LIST';

$lang['import_data_head'] = 'IMPORT SPARE PART';
$lang['import_data_bread'] = 'Import Data';

$lang['regulation_head'] = 'REACH REGULATON'; 
$lang['regulation'] = 'Reach Regulation'; 


$lang['save'] = 'Save';
$lang['update'] = 'Update';
$lang['submit'] = 'Submit';
$lang['comment'] = 'Comment';
$lang['something_went_wrong'] = 'Something went wrong';
$lang['duplicate_record'] = 'Dupicate record';
$lang['reset'] = 'Reset';
$lang['search'] = 'Search';
$lang['deactivate'] = 'Deactivate';
$lang['activate'] = 'Activate';
$lang['export_data'] = 'Export';
$lang['import_data'] = 'IMPORT';
$lang['reach_regulation'] = 'Reach Regulation';
$lang['spare_part_number'] = 'Spare Part Number';
$lang['brand'] = 'Brand';
$lang['cas_number'] = 'CAS Number';
$lang['substance_name'] = 'Substance Name';
$lang['article_may_contain'] = 'Article May Contain';
$lang['status'] = 'Status';
$lang['save'] = 'Save';
$lang['data_added_successfully'] = 'Data Added Successfully';
$lang['data_updated_successfully'] = 'Data Updated Successfully';
$lang['data_deleted_successfully'] = 'Record Deleted Successfully';
$lang['spare_part_no'] = 'Spare part no.';
$lang['cas_no'] = 'CAS No.';
$lang['substance'] = 'Substance';
$lang['article'] = 'Article';
$lang['action'] = 'Action';
$lang['choose_file'] = 'Choose file';
$lang['import'] = 'Import';
$lang['import_successful'] = 'File Successfully Imported';
$lang['enter_spare_part_reference'] = 'Please Enter Spare Part Reference Number';
$lang['first_five_character'] = 'Please Enter Atleast First 5 Characters Of Spare Part Reference Number';
$lang['search_spare_part_by_reference'] = 'Search Spare part by reference';
$lang['enter_spare_part_number'] = 'Enter Spare Part Number';
$lang['filetoupload'] = 'Choose File to upload';
$lang['reach_regulation_error'] = 'Please Enter Regulation To Update';
$lang['maxallowedimport'] = 'Max allowed filesize 1 MB';
$lang['enter_spare_part_Number'] = 'Enter Spare Part Number';
$lang['enter_brand'] = 'Enter Brand';
$lang['enter_cs_number'] = 'Enter CAS Number';
$lang['enter_substance_name'] = 'Enter Substance Name';
$lang['enter_article_may_conatain'] = 'Enter Article May Conatine';
$lang['exact_length_one'] = 'Enter a minimum length of';
$lang['exact_length_two'] = 'characters.';
$lang['max_length_one'] = 'You entered more than';
$lang['logout_success'] = 'You have been successfully logged out.';
$lang['next'] = 'Next';
$lang['last'] = 'Last';
$lang['first'] = 'First';
$lang['previous'] = 'Previous';
$lang['no_result_found'] = 'No results';
$lang['showing_records'] = 'Showing _START_ to _END_ of _TOTAL_ records';
$lang['records_per_page'] = '_MENU_ entries per page';
$lang['field_name'] = 'Modifications Of';
$lang['old_data'] = 'OLD VALUE';
$lang['new_data'] = 'NEW VALUE';
$lang['atleast_one_field'] = 'Please fill at least one of these fields..';
			

?>