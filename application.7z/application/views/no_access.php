<!DOCTYPE html>
<?php 
$languageDirectionArray= array();
$languageDirectionArray= $this->config->item('languageDirectionArray');
if(!empty($this->session->userdata('language'))){
	$language = $this->session->userdata('language');
	$lang = strtoupper($language);
}else{
	$lang = $this->config->item('DEFAULT_LANG');
	$language = 'en';
}
$languageDirection = $languageDirectionArray[$lang];

?>
<html dir="<?php echo $languageDirection;?>" lang=<?php echo $lang;?>>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    <?php echo $this->lang->line('logout'); ?>
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
   
	<link href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css" rel="stylesheet" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/libs/quill/dist/quill.snow.css">
	<link href="<?php echo base_url(); ?>/assets/css/datatables.net-bs4/css/dataTables.bootstrap4.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>/assets/css/style.min.css" rel="stylesheet">
	<?php	if($this->session->userdata('language') != '') 	{ ?>
	<link href="<?php echo base_url(); ?>/assets/css/language/style_<?php echo $this->session->userdata('language');?>.css" rel="stylesheet" />
		<?php } else { ?> <link href="<?php echo base_url(); ?>/assets/css/style.css" rel="stylesheet" /> <?php } ?>
	<link href="<?php echo base_url(); ?>/assets/css/font-awesome.css" rel="stylesheet" />
	<link href="<?php echo base_url(); ?>/assets/css/toastr.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/flag-icon.min.css">
</head>
<body>
	<div class="content">
		<!--<div class ="heading-color">
		<h5 class="page-heading">		
		  <small title="<?php echo $this->lang->line('logout_success');?>">
          <?php

          echo $this->lang->line('logout_success');
		  ?></small>
		</h5>
	</div> -->
 <div class="error-box">
            <div class="error-body text-center">
                
                <h2 class="text-uppercase error-subtitle text-danger">403</h2>
                <p class="text-muted m-t-30 m-b-30">Unauthorised Access</p>
                <a href="<?php echo base_url(); ?>Welcome" class="btn btn-danger btn-rounded waves-effect waves-light m-b-40">Back to home</a> </div>
        </div>
</div>
</body>

</html>

